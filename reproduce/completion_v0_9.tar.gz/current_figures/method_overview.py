"""Draw the actual polymer-graph workflow, without predictions or target labels.

Upgraded to Advisor's Preferred Plotting Style:
- Sans-serif Arial Bold typography
- Bold box borders (1.6 pt) and bold connectors (1.5 pt)
- Advisor's palette:
  * Periodic Trimer & Closure Edge: #C82423 (Crimson Red)
  * Open Trimer & Base Encoder: #2878B4 (Classic Royal Blue)
  * Multitask & High-Value Head: #F4AE6F (Warm Amber / Coral)
"""
from pathlib import Path
import csv
import hashlib
import json
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle, Circle
import numpy as np
from rdkit import Chem
from rdkit.Chem import rdDepictor

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
import argparse
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=False);QA=OUT/'qa';QA.mkdir()
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(HERE.parent/'completion/figures/code/qa_tools'))
from polymer_dmpnn.graph import build_trimer_graph
from audit_panel_alignment import require_matplotlib_panel_alignment
record=json.loads((HERE/'method_structure.json').read_text());RID=record['record_id'];SMILES=record['smiles']
source = Chem.MolFromSmiles(SMILES)
stars = sorted(a.GetIdx() for a in source.GetAtoms() if a.GetAtomicNum() == 0)
unit = [a.GetIdx() for a in source.GetAtoms() if a.GetAtomicNum() != 0]
index = {old: new for new, old in enumerate(unit)}
left = index[source.GetAtomWithIdx(stars[0]).GetNeighbors()[0].GetIdx()]
right = index[source.GetAtomWithIdx(stars[1]).GetNeighbors()[0].GetIdx()]
n = len(unit)
rdDepictor.Compute2DCoords(source)
conf = source.GetConformer()
raw = np.array([[conf.GetAtomPosition(i).x, conf.GetAtomPosition(i).y]
                for i in range(source.GetNumAtoms())])
v = raw[unit[right]] - raw[unit[left]]
theta = np.arctan2(v[1], v[0])
rot = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
raw = (raw - raw[unit[left]]) @ rot
xy = raw[unit]
step = xy[:, 0].max() - xy[:, 0].min() + 1.6
coords = np.concatenate([xy + [i * step, 0] for i in range(3)])

rw = Chem.RWMol(Chem.CombineMols(Chem.CombineMols(source, source), source))
for i in sorted([k * source.GetNumAtoms() + s for k in range(3) for s in stars], reverse=True):
    rw.RemoveAtom(i)
for k in range(2):
    rw.AddBond(k*n + right, (k+1)*n + left, Chem.BondType.SINGLE)
trimer = rw.GetMol()
Chem.SanitizeMol(trimer)
Chem.Kekulize(trimer, clearAromaticFlags=True)
monomer = Chem.Mol(source)
Chem.Kekulize(monomer, clearAromaticFlags=True)
open_graph = build_trimer_graph(SMILES, periodic_closure=False)
periodic_graph = build_trimer_graph(SMILES, periodic_closure=True)
def undirected(g):
    return {tuple(sorted(map(int, pair))) for pair in g.edge_index.T}
closure = tuple(sorted((left, 2*n + right)))
assert undirected(periodic_graph) - undirected(open_graph) == {closure}
assert np.array_equal(open_graph.atom_features, periodic_graph.atom_features)
assert open_graph.atom_features.shape == (3*n, 133)
assert open_graph.edge_features.shape[1] == 14
assert undirected(open_graph) == {
    tuple(sorted((b.GetBeginAtomIdx(), b.GetEndAtomIdx()))) for b in trimer.GetBonds()}

# Advisor's palette
INK = '#151A20'
GRAY = '#5A646E'
BLUE = '#2878B4'       # Open Trimer & Base Encoder
RED = '#C82423'        # Periodic Trimer & Closure Edge
ORANGE = '#F4AE6F'     # Multitask Head
PALE = '#F4F6F8'
LIGHTBLUE = '#EBF3F8'
LIGHTRED = '#FAECEB'
LIGHTORANGE = '#FEF6ED'

plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Calibri', 'Helvetica', 'DejaVu Sans'],
    'font.size': 8.0,
    'font.weight': 'normal',
    'text.color': INK,
    'axes.labelcolor': INK,
    'svg.fonttype': 'none',
    'pdf.fonttype': 42
})

fig = plt.figure(figsize=(183/25.4, 125/25.4), facecolor='white')
background = fig.add_axes([0, 0, 1, 1]); background.set_axis_off()
background.set(xlim=(0, 1), ylim=(0, 1))

fig.text(.025, .960, 'a', fontweight='bold', fontsize=11.5)
fig.text(.055, .960, 'Repeat-unit connectivity and the matched graph contrast', fontweight='bold', fontsize=9.5)
fig.text(.025, .882, 'Repeat unit', fontsize=8.0)
fig.text(.255, .882, 'Open trimer (baseline)', fontweight='bold', color=BLUE, fontsize=8.5)
fig.text(.625, .882, 'Periodic trimer (closure)', fontweight='bold', color=RED, fontsize=8.5)

ax_unit = fig.add_axes([.025, .600, .16, .265])
ax_open = fig.add_axes([.255, .595, .345, .270])
ax_periodic = fig.add_axes([.625, .595, .345, .270])

def draw_chem(ax, mol, positions, periodic=False):
    origin = ax.transData.transform([0, 0])
    scale = np.linalg.norm(ax.transData.transform([1, 0])-origin) * 72/fig.dpi
    def label_clearance(atom, direction):
        if atom.GetAtomicNum() == 6:
            return 0.0
        half_width = 3.5 if atom.GetAtomicNum() == 0 else 4.5
        half_height = 5.5
        dx, dy = abs(direction[0]), abs(direction[1])
        return min(half_width/max(dx,1e-12), half_height/max(dy,1e-12))/scale
    for bond in mol.GetBonds():
        i, j = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        a, b = positions[i].copy(), positions[j].copy()
        vec = b-a; length = np.linalg.norm(vec); direction = vec/length
        normal = np.array([-direction[1], direction[0]])
        a += label_clearance(mol.GetAtomWithIdx(i), direction)*direction
        b -= label_clearance(mol.GetAtomWithIdx(j), direction)*direction
        if bond.GetBondTypeAsDouble() == 2:
            for sign in (-1, 1):
                aa, bb = a+sign*.06*normal, b+sign*.06*normal
                ax.plot([aa[0], bb[0]], [aa[1], bb[1]], lw=1.2, color=INK, solid_capstyle='round')
        else:
            ax.plot([a[0], b[0]], [a[1], b[1]], lw=1.4, color=INK, solid_capstyle='round')
    for atom in mol.GetAtoms():
        if atom.GetAtomicNum() == 6: continue
        p = positions[atom.GetIdx()]
        symbol = '*' if atom.GetAtomicNum() == 0 else atom.GetSymbol()
        color = {'N': BLUE, 'O': RED}.get(symbol, INK)
        ax.text(p[0], p[1], symbol, fontsize=8.0, color=color, ha='center', va='center')
    if mol.GetNumAtoms() == 3*n:
        u, v = closure
        for k in (u, v):
            ax.add_patch(Circle(positions[k], 7.0/scale, fill=False, ec=RED if periodic else BLUE, lw=1.4))
        if periodic:
            ax.add_patch(FancyArrowPatch(tuple(positions[u]), tuple(positions[v]),
                connectionstyle='arc3,rad=-0.135', arrowstyle='-',
                shrinkA=7.0, shrinkB=7.0, color=RED, linewidth=1.8,
                linestyle=(0, (3, 2)), zorder=0))
    ax.set_axis_off(); ax.set_aspect('equal')

ax_unit.set_xlim(raw[:,0].min()-.5, raw[:,0].max()+.5)
ax_unit.set_ylim(raw[:,1].min()-.35, raw[:,1].max()+.35)
for ax in [ax_unit, ax_open, ax_periodic]:
    ax.set_axis_off(); ax.set_aspect('equal')
for ax in [ax_open, ax_periodic]:
    ax.set_xlim(coords[:,0].min()-.6, coords[:,0].max()+.6)
    ax.set_ylim(coords[:,1].min()-.65, coords[:,1].max()+1.6)
fig.canvas.draw()
draw_chem(ax_unit, monomer, raw)
for ax, periodic in [(ax_open, False), (ax_periodic, True)]:
    draw_chem(ax, trimer, coords, periodic)

def arrow(p, q, color=GRAY, linestyle='-'):
    background.add_patch(FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=9,
        lw=1.5, color=color, linestyle=linestyle, shrinkA=1, shrinkB=1))

arrow((.192, .727), (.243, .727))
fig.text(.025, .555, '*  Chain continuation site', fontweight='bold', fontsize=7.5)
fig.text(.255, .551, 'Dashed edge: repeat-unit continuation', fontweight='bold', fontsize=7.5, color=RED)
fig.text(.255, .503, 'Same features, network architecture and training schedule', fontsize=7.5)
background.plot([.025, .975], [.440, .440], color='#CBD3D8', lw=1.0)

# Three complementary lower panels expose the actual computation.
for x,letter,label in [(.025,'b','Directed bond update'),(.425,'c','Graph readout'),(.735,'d','Prediction objectives')]:
    fig.text(x,.395,letter,fontweight='bold',fontsize=10)
    fig.text(x+.028,.395,label,fontsize=8.5)

def node(x,y,label):
    background.add_patch(Circle((x,y),.018,fc='white',ec=BLUE,lw=1))
    background.text(x,y,label,ha='center',va='center',fontsize=8)
node(.075,.265,'w');node(.195,.265,'u');node(.315,.265,'v')
arrow((.094,.265),(.174,.265),BLUE)
arrow((.215,.265),(.294,.265),RED)
arrow((.295,.235),(.215,.235),'#B9C0C5',linestyle='--')
background.plot([.250,.265],[.226,.244],color=RED,lw=1)
background.plot([.250,.265],[.244,.226],color=RED,lw=1)
background.text(.13,.305,'Incoming message',ha='center',fontsize=7)
background.text(.26,.305,'Updated state',ha='center',fontsize=7)
background.text(.195,.185,'Reverse message excluded',ha='center',fontsize=7)
background.text(.195,.13,'Initialize → 2 message updates',ha='center',fontsize=7.5)
background.text(.195,.085,'133 atom features · 14 bond features',ha='center',fontsize=7)

# Atom embeddings and their shared mean-pooled graph vector.
for k,y in enumerate([.30,.25,.20]):
    for j in range(6):
        background.add_patch(Rectangle((.445+j*.017,y),.013,.024,fc=BLUE,alpha=.20+.12*((j+k)%5),ec='none'))
background.text(.493,.342,'Atom states',ha='center',fontsize=7.5)
arrow((.555,.262),(.600,.262))
for j in range(6):
    background.add_patch(Rectangle((.615+j*.011,.22),.008,.085,fc=RED,alpha=.25+.10*(j%5),ec='none'))
background.text(.647,.342,'Graph vector',ha='center',fontsize=7.5)
background.text(.555,.14,'Mean pooling',ha='center',fontsize=7.5)
background.text(.555,.095,'128-dimensional embedding',ha='center',fontsize=7)

# A shared hidden readout feeds regression and optional classification.
def head(x,y,w,h,text,edge,fill):
    background.add_patch(Rectangle((x,y),w,h,fc=fill,ec=edge,lw=1))
    background.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=7.5)
head(.745,.22,.08,.075,'128-unit\nreadout',GRAY,PALE)
head(.86,.285,.115,.065,'κ regression',RED,LIGHTRED)
head(.86,.16,.115,.065,'High-value score',ORANGE,LIGHTORANGE)
background.plot([.825,.842,.842],[.2575,.2575,.3175],color=GRAY,lw=1)
arrow((.842,.3175),(.86,.3175))
background.plot([.842,.842],[.2575,.1925],color=GRAY,lw=1)
arrow((.842,.1925),(.86,.1925))
background.text(.9175,.125,'Multitask only',ha='center',fontsize=7)
background.text(.855,.075,'MSE + 0.2 × weighted BCE',ha='center',fontsize=7)
background.text(.025,.025,'Hydrogen atoms omitted; 2D coordinates illustrate connectivity and are not model inputs.',fontsize=7)

fig.canvas.draw()
require_matplotlib_panel_alignment(fig, axes=[ax_open, ax_periodic],
    panel_ids=['open', 'periodic'], row_groups=[['open', 'periodic']],
    json_out=QA/'method_overview.alignment.json',
    overlay_svg=QA/'method_overview.alignment.svg', strict=True)
stem = OUT/'Figure_1_Method_Overview'
fig.savefig(str(stem)+'.pdf', facecolor='white')
fig.savefig(str(stem)+'.svg', facecolor='white')

import re
svg_path=stem.with_suffix('.svg')
svg_text=re.sub(r'<!DOCTYPE[^>]*>', '', svg_path.read_text(), flags=re.S)
from xml.etree import ElementTree as ET
ET.register_namespace('', 'http://www.w3.org/2000/svg')
ET.register_namespace('xlink', 'http://www.w3.org/1999/xlink')
svg_root=ET.fromstring(svg_text)
for element in svg_root.iter():
    style=element.attrib.get('style', '')
    match=re.search(r'font-size:\s*([0-9.]+)px;?', style)
    if match:
        element.set('font-size', match.group(1))
        element.set('style', style[:match.start()]+style[match.end():])
svg_path.write_bytes(ET.tostring(svg_root, encoding='utf-8', xml_declaration=True))
fig.savefig(stem.with_suffix('.png'), dpi=600, facecolor='white')
fig.savefig(stem.with_suffix('.tiff'), dpi=600, facecolor='white',
            pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)

identity = {'record_id':RID,'smiles':SMILES,'unit_atoms':n,
            'trimer_atoms':3*n,'open_edges':len(undirected(open_graph)),
            'closure_undirected':list(closure),'atom_features_equal':True,
            'data_access':'bundled structure-only JSON; no labels/checkpoints/predictions',
            'graph_source_sha256':hashlib.sha256((ROOT/'polymer_dmpnn/graph.py').read_bytes()).hexdigest(),
            'references':['https://arxiv.org/abs/2205.13757','https://doi.org/10.1021/acs.jcim.9b00237'],
            'dimensions_mm':[183,125]}
(QA/'method_overview_identity.json').write_text(json.dumps(identity, indent=2))
print('Rebuilt Figure_1_Method_Overview with advisor styling.')
