from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
import argparse
ap=argparse.ArgumentParser(description='Replot main Figure 2 from all saved paired doubling predictions');ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(HERE.parent/'completion/figures/code/qa_tools'))
from audit_panel_alignment import require_matplotlib_panel_alignment
df=pd.read_csv(HERE/'doubling_predictions.csv')
good=df[df.eligible==True].copy()
assert len(good)==186 and good.record_id.nunique()==93
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
 'font.size':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.8,
 'pdf.fonttype':42,'svg.fonttype':'none','legend.frameon':False})
fig,axs=plt.subplots(1,2,figsize=(7.15,2.95))
fig.subplots_adjust(left=.09,right=.98,bottom=.24,top=.84,wspace=.45)
colors=['#2878B4','#C82423']
rng=np.random.default_rng(20261029)
for i,(arm,col) in enumerate(zip(['open','periodic'],colors)):
 x=good[good.model_id.str.contains('_'+arm+'_')]
 axs[0].scatter(x.original_prediction_W_mK,x.doubled_prediction_W_mK,s=16,alpha=.65,c=col,
                marker='o' if i==0 else '+',label=arm.capitalize(),linewidths=.6)
 vals=x.absolute_difference_W_mK.to_numpy()*1000
 # Randomness spreads points horizontally only; all response values are saved prediction differences.
 axs[1].scatter(i+rng.uniform(-.10,.10,len(vals)),vals,s=13,alpha=.6,color=col,linewidths=0)
 axs[1].plot([i-.17,i+.17],[np.median(vals)]*2,color=col,lw=2)
lo=float(min(good.original_prediction_W_mK.min(),good.doubled_prediction_W_mK.min()))-.01
hi=float(max(good.original_prediction_W_mK.max(),good.doubled_prediction_W_mK.max()))+.01
axs[0].plot([lo,hi],[lo,hi],color='#777777',ls='--',lw=.8,zorder=0)
axs[0].set(xlim=(lo,hi),ylim=(lo,hi),xlabel='Original-unit prediction (W/(m K))',ylabel='Doubled-unit prediction (W/(m K))')
axs[0].legend(loc='upper left',fontsize=7)
axs[1].set(xticks=[0,1],xticklabels=['Open','Periodic'],xlim=(-.45,1.45),
 ylabel='Absolute change\n(10^-3 W/(m K))')
for ax,l,t in zip(axs,'ab',['Equivalent-input predictions','Repeat-length sensitivity']):
 ax.set_title(t,loc='left',fontsize=8,pad=10)
 ax.annotate(l,xy=(0,1),xycoords='axes fraction',xytext=(-17,10),textcoords='offset points',fontsize=10,fontweight='bold',annotation_clip=False)
axs[1].text(.96,.96,'n = 93 structures\nOne checkpoint pair',transform=axs[1].transAxes,ha='right',va='top',fontsize=7)
fig.canvas.draw()
require_matplotlib_panel_alignment(fig,strict=True,json_out=OUT/'figure.alignment.json',overlay_svg=OUT/'figure.alignment.svg')
stem=OUT/'Figure_2_Representation_Consistency'
fig.savefig(stem.with_suffix('.pdf'))
fig.savefig(stem.with_suffix('.svg'))
fig.savefig(stem.with_suffix('.png'),dpi=600)
fig.savefig(stem.with_suffix('.tiff'),dpi=600,pil_kwargs={'compression':'tiff_lzw'})
plt.close(fig)
good.to_csv(OUT/'figure_source_data.csv',index=False)
print('Exported Figure S6 from all 93 eligible paired structures.')
