# Main Figures 1 and 2

These portable copies use the same plotting geometry as the manuscript. Figure 1 uses one structure-only PolyOmics excerpt (CC BY4.0); Figure 2 uses saved paired predictions for the93 admitted structures. Neither script loads weights, fits a model or performs a model forward pass.

Install from the repository root with `python -m pip install ".[reproduce,figures]"`, then run:

```bash
python reproduce/current_figures/method_overview.py --output figure1
python reproduce/current_figures/representation.py --output figure2
```

Output folders must be new. Each writes PNG600dpi, vector PDF/SVG and alignment evidence. Font availability can change raster bytes across platforms. The numerical points and definitions remain fixed. Main Figures3–5 are regenerated with `reproduce/completion/plot.py`.
