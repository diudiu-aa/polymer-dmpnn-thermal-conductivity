"""Load one exact completion checkpoint; never average models or refit."""
import argparse,json,math,sys
from pathlib import Path
import numpy as np
import torch
from integrity import BASE,verify_package
REPO=BASE.parents[1]
sys.path.insert(0,str(REPO))

def load_model(model_id):
 _,registry=verify_package()
 from polymer_dmpnn.graph import PeriodicDMPNN
 from polymer_dmpnn.paper import MultitaskDMPNN
 if model_id not in registry:raise ValueError('UNKNOWN_MODEL_ID')
 spec=registry[model_id];checkpoint=torch.load(BASE/spec['file'],map_location='cpu',weights_only=True)
 for k,key in [('target_mean','target_mean'),('target_sd','target_sd_ddof0')]:
  if checkpoint[k]!=spec[key] or not math.isfinite(checkpoint[k]):raise ValueError('NORMALIZATION_MISMATCH')
 if checkpoint['target_sd']<=0:raise ValueError('INVALID_TARGET_SD')
 model=MultitaskDMPNN() if spec['architecture']=='MultitaskDMPNN' else PeriodicDMPNN(133,14,hidden_size=128,depth=3,dropout=.1)
 model.load_state_dict(checkpoint['state_dict'],strict=True)
 if sum(p.numel() for p in model.parameters())!=spec['parameters']:raise ValueError('PARAMETER_COUNT_MISMATCH')
 if not all(torch.isfinite(p).all() for p in model.parameters()):raise ValueError('NONFINITE_CHECKPOINT')
 model.eval();return model,spec

def predict(model_id,smiles):
 if not isinstance(smiles,list) or not smiles or not all(isinstance(s,str) and s.strip() for s in smiles):raise ValueError('Expected nonempty JSON list of SMILES strings')
 torch.set_num_threads(1);model,spec=load_model(model_id)
 from polymer_dmpnn.graph import build_trimer_graph,batch_graphs
 values=[];logits=[]
 with torch.inference_mode():
  for off in range(0,len(smiles),16):
   graphs=[build_trimer_graph(s,periodic_closure=spec['periodic']) for s in smiles[off:off+16]];out=model(batch_graphs(graphs));reg,cls=out if spec['architecture']=='MultitaskDMPNN' else (out,None)
   values.extend((reg.numpy()*spec['target_sd_ddof0']+spec['target_mean']).tolist())
   if cls is not None:logits.extend(cls.numpy().tolist())
 if not np.isfinite(values).all() or not np.isfinite(logits).all():raise ValueError('NONFINITE_PREDICTION')
 rows=[{'smiles':s,'model_id':model_id,'prediction_W_mK':float(v)} for s,v in zip(smiles,values)]
 if logits:
  for row,logit in zip(rows,logits):row['classification_logit']=float(logit)
 return rows

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--list-models',action='store_true');ap.add_argument('--model-id');ap.add_argument('--smiles-json',type=Path);ap.add_argument('--output',type=Path);a=ap.parse_args()
 if a.list_models:
  print('\n'.join(verify_package()[1]));return
 if not a.model_id or not a.smiles_json or not a.output:ap.error('--model-id, --smiles-json and --output are required')
 result=predict(a.model_id,json.loads(a.smiles_json.read_text()));a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
if __name__=='__main__':main()
