"""Portable fixed 600-label /9400-update training. Default is a target-blind dry-run.
Explicit --run starts fitting; there is no checkpoint selection or automatic retry.
"""
import argparse,csv,gzip,hashlib,json,math,os,signal,sys,tempfile,time,traceback
from pathlib import Path
from integrity import BASE,load_json,unpack,verify_package
REPO=BASE.parents[1]
def lr(step):return 1e-4+step*9e-4/376 if step<=376 else 1e-3*.1**((step-376)/9024)
def ordered_sha(ids):return hashlib.sha256(('\n'.join(ids)+'\n').encode()).hexdigest()
def save(p,obj):Path(p).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def roles():
 with tempfile.TemporaryDirectory(prefix='completion-roles-') as tmp:
  d=unpack(Path(tmp));return load_json(d/'budget/protocol.json')['splits']
def build_plan(seed='all',arm='both'):
 _,registry=verify_package();splits=roles();ss=range(32101,32106) if seed=='all' else [int(seed)];aa=('open','periodic') if arm=='both' else [arm]
 plans=[]
 public=load_json(REPO/'reproduce/inputs/splits.json')
 for s in ss:
  tr=splits[str(s)]['train'];va=splits[str(s)]['validation']
  if tr!=public[str(s)]['table5']['train'] or va!=public[str(s)]['table5']['validation']:raise ValueError('ORIGINAL_PUBLIC_600_400_ROLE_MISMATCH')
  if len(tr)!=600 or len(va)!=400 or set(tr)&set(va):raise ValueError('INVALID_FROZEN_ROLES')
  for a in aa:plans.append({'model_id':f'budget_{s}_{a}','seed':s,'arm':a,'train_ids':tr,'validation_ids':va,'train_order_sha256':ordered_sha(tr),'validation_order_sha256':ordered_sha(va),'updates':9400,'warmup_steps':376,'last_partial_epoch_observations':224})
 return plans,registry

def run(plans,registry,output):
 for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[name]='1'
 import numpy as np
 import torch
 sys.path.insert(0,str(REPO))
 from polymer_dmpnn.graph import PeriodicDMPNN,build_trimer_graph,batch_graphs
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
 output=Path(output);output.mkdir(parents=True,exist_ok=False)
 save(output/'frozen_plan.json',{'plans':plans,'fit_cap':10,'per_fit_seconds_cap':300,'total_seconds_cap':2400,'default_loss':'own-600 standardized MSE','endpoint':'fixed9400; no intermediate scoring or best checkpoint','seed_rules':'initialization=seed; dropout=seed+20000; permutation=seed+10000'})
 start=time.monotonic();receipts=[];active=None;model=None;step=0
 def timeout(sig,frame):raise TimeoutError('HARD_WALL_TIME_CAP')
 signal.signal(signal.SIGALRM,timeout)
 try:
  for plan in plans:
   st=time.monotonic();remaining=2400-(st-start)
   if remaining<=0:raise TimeoutError('TOTAL2400_CAP')
   signal.setitimer(signal.ITIMER_REAL,min(300,remaining));model=None;step=0;active=output/plan['model_id'];active.mkdir();seed=plan['seed'];arm=plan['arm'];tr=plan['train_ids'];va=plan['validation_ids'];target={};meta={};wanted=set(tr+va);allow=set(tr)
   # Numerical conversion is restricted to this fit's own600 training labels.
   with gzip.open(REPO/'reproduce/inputs/records.csv.gz','rt',newline='') as f:
    for row in csv.DictReader(f):
     rid=row['record_id']
     if rid not in wanted:continue
     if rid in meta:raise ValueError('DUPLICATE_INPUT_RECORD')
     meta[rid]={k:row[k] for k in ('smiles','source_uuid','isolation_group','cluster_id')}
     if rid in allow:
      y=float(row['kappa_W_mK'])
      if not math.isfinite(y) or y<=0:raise ValueError('INVALID_TRAINING_TARGET')
      target[rid]=y
   if set(meta)!=wanted or set(target)!=allow:raise ValueError('MISSING_FIXED_INPUT')
   for key in ('source_uuid','isolation_group','cluster_id','smiles'):
    if {meta[i][key] for i in tr}&{meta[i][key] for i in va}:raise ValueError('TRAIN_EVALUATION_OVERLAP_'+key)
   yy=np.array([target[i] for i in tr]);mu=float(yy.mean());sd=float(yy.std());spec=registry[plan['model_id']]
   if mu!=spec['target_mean'] or sd!=spec['target_sd_ddof0']:raise ValueError('ORIGINAL_600_STANDARDIZATION_CHANGED')
   save(active/'config.json',{**plan,'target_mean':mu,'target_sd':sd,'graph':'trimer','depth':3,'hidden':128,'dropout':.1,'batch':16,'optimizer':'Adam defaults','lr':'warm376 then exponential to1e-4 at9400','selection':'fixed terminal step'})
   graphs=[build_trimer_graph(meta[i]['smiles'],periodic_closure=arm=='periodic') for i in tr+va]
   torch.manual_seed(seed);model=PeriodicDMPNN(133,14,hidden_size=128,depth=3,dropout=.1);torch.manual_seed(seed+20000);opt=torch.optim.Adam(model.parameters(),lr=1e-4);rng=np.random.default_rng(seed+10000);step=0;epoch=0;model.train();total_obs=0
   with (active/'training_curve.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['epoch','steps','objective','observations_epoch','elapsed_seconds','lr']);w.writeheader()
    while step<9400:
     epoch+=1;perm=rng.permutation(600);lossum=0.;n=0
     for off in range(0,600,16):
      if step==9400:break
      ix=perm[off:off+16];step+=1
      for pg in opt.param_groups:pg['lr']=lr(step)
      opt.zero_grad();prediction=model(batch_graphs([graphs[int(j)] for j in ix]));truth=torch.as_tensor((yy[ix]-mu)/sd,dtype=torch.float32);loss=((prediction-truth)**2).mean()
      if not torch.isfinite(loss):raise ValueError('NONFINITE_LOSS')
      loss.backward()
      if not all(v.grad is None or torch.isfinite(v.grad).all() for v in model.parameters()):raise ValueError('NONFINITE_GRADIENT')
      opt.step();lossum+=float(loss.detach())*len(ix);n+=len(ix);total_obs+=len(ix)
     w.writerow({'epoch':epoch,'steps':step,'objective':lossum/n,'observations_epoch':n,'elapsed_seconds':time.monotonic()-st,'lr':lr(step)});f.flush()
   if (step,epoch,n,total_obs)!=(9400,248,224,148424):raise ValueError('FIXED_ENDPOINT_MISMATCH')
   if not all(torch.isfinite(v).all() for v in model.parameters()):raise ValueError('NONFINITE_PARAMETERS')
   model.eval();pred=[]
   with torch.inference_mode():
    for off in range(0,400,16):pred.extend((model(batch_graphs(graphs[600+off:600+off+16])).numpy()*sd+mu).tolist())
   if not np.isfinite(pred).all():raise ValueError('NONFINITE_PREDICTIONS')
   with (active/'predictions.csv').open('w',newline='') as f:w=csv.writer(f);w.writerow(['record_id','prediction']);w.writerows(zip(va,pred))
   torch.save({'state_dict':model.state_dict(),'target_mean':mu,'target_sd':sd},active/'weights.pt')
   receipt={'model_id':plan['model_id'],'steps':step,'elapsed_seconds':time.monotonic()-st,'training_targets':600,'evaluation_target_values_read':0,'last_partial_epoch_observations':224,'weights_sha256':hashlib.sha256((active/'weights.pt').read_bytes()).hexdigest(),'predictions_sha256':hashlib.sha256((active/'predictions.csv').read_bytes()).hexdigest()};save(active/'complete.json',receipt);receipts.append(receipt);save(output/'ledger.json',{'status':'RUNNING','fits_completed':len(receipts),'runs':receipts});signal.setitimer(signal.ITIMER_REAL,0)
  save(output/'ledger.json',{'status':'COMPLETE','fits_completed':len(receipts),'elapsed_seconds':time.monotonic()-start,'evaluation_targets_read':0,'runs':receipts})
 except BaseException as e:
  signal.setitimer(signal.ITIMER_REAL,0)
  if active and model is not None:torch.save({'state_dict':model.state_dict(),'steps':step},active/'partial_STOP.pt')
  save(output/'STOP.json',{'error':repr(e),'traceback':traceback.format_exc(),'fits_completed':len(receipts),'active_steps':step,'no_automatic_retry':True});raise
 finally:signal.setitimer(signal.ITIMER_REAL,0)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--seed',choices=['all']+[str(s) for s in range(32101,32106)],default='all');ap.add_argument('--arm',choices=['both','open','periodic'],default='both');ap.add_argument('--output',type=Path);ap.add_argument('--run',action='store_true');a=ap.parse_args();plans,registry=build_plan(a.seed,a.arm)
 if not a.run:
  print(json.dumps({'status':'DRY_RUN','fits_started':0,'forwards':0,'target_values_read':0,'fits_planned':len(plans),'configuration':{'labels':600,'evaluation_records':400,'updates':9400,'warmup_steps':376,'full_epochs':247,'last_epoch_batches':14,'last_epoch_observations':224,'lr_first':lr(1),'lr_at376':lr(376),'lr_at9400':lr(9400),'threads':1,'per_fit_seconds_cap':300,'total_seconds_cap':2400},'model_ids':[p['model_id'] for p in plans]},indent=2));return
 if a.output is None:ap.error('--output is required with explicit --run')
 run(plans,registry,a.output)
if __name__=='__main__':main()
