# Scientific figures / 科研图复绘

图B对应主文Figure3（训练预算与周期收益），C对应Figure4（HK01目标取舍），A对应Figure5（跨来源诊断）。图注和解释边界见`CAPTIONS.md`。

```bash
python -m pip install numpy pandas matplotlib
python reproduce/completion/replay.py --output reproduced-completion
python reproduce/completion/plot.py --replay-output reproduced-completion --figure B --output figure3
python reproduce/completion/plot.py --replay-output reproduced-completion --figure C --output figure4
python reproduce/completion/plot.py --replay-output reproduced-completion --figure A --download-reference --output figure5
```

`--figure all`生成全部三图，需同样指定`--download-reference`或`--reference-csv`。APFE作者固定URL与SHA在`source_data/apfe_reference_manifest.json`；仅内存中提取冻结93个ID，不保存或重分发作者逐条参考值。离线提供相同原CSV可用`--reference-csv`。B/C完全离线。

The wrapper uses newly recomputed A/B tables from the specified replay output, stages the remaining frozen aggregate sources in a temporary directory, and removes it. It writes PDF/SVG vector figures,600dpi PNG and alignment checks only to `--output`. It does not modify bundled source tables or run a model. Source inputs include our predictions/nearest-training similarities and aggregate external diagnostics; no individual APFE reference, residual or absolute-error column is redistributed.

Underlying reusable interface: `figures/code/make_figures.py --figure A|B|C|all --source-dir <sources> --output-dir <outputs>`, with the same APFE flags for A/all. The plotting code was adapted only so derived plotted-effect tables are written to the output directory rather than back into the input directory. Preserve `code/qa_tools/audit_panel_alignment.py` alongside it.

B's same9400-step budget difference-in-differences and long-minus-short interaction intervals cross zero;1900-step support must not be generalized to both schedules. C uses the new3000/600 HK01 design, with39 high records/11 clusters; deletion sensitivity and direct weighted comparisons must remain visible. A shows one fixed seed's93 candidates and aggregate context; repeat predictions from five models are not additional independent materials. Nearest similarity is retrospective association, not a transport mechanism or calibration repair. See the data attribution notices in the parent directory.
