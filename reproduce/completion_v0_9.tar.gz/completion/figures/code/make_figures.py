"""Render frozen saved-result figure candidates; no model or raw-target reads."""
from pathlib import Path
import argparse, json, sys, hashlib, csv, io, urllib.request
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import TwoSlopeNorm
sys.path.insert(0,str(Path(__file__).resolve().parent/'qa_tools'))
from audit_panel_alignment import require_matplotlib_panel_alignment
ROOT=Path(__file__).resolve().parents[1]
S=ROOT/'source_data'; O=ROOT/'figures'; A=ROOT/'audit'
BLUE='#42779D'; RUST='#B86A3D'; GREY='#8B8B8B'; DARK='#303030'
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],
 'font.size':8,'axes.labelsize':8,'axes.titlesize':8,'xtick.labelsize':8,'ytick.labelsize':8,
 'legend.fontsize':8,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,
 'xtick.major.width':.7,'ytick.major.width':.7,'legend.frameon':False,'pdf.fonttype':42,
 'svg.fonttype':'none','savefig.facecolor':'white','axes.unicode_minus':False})

def label(ax,letter,title):
    ax.set_label(letter)
    ax.annotate(letter,(0,1),xycoords='axes fraction',xytext=(-17,13),textcoords='offset points',
        fontsize=9,fontweight='bold',va='bottom')
    ax.set_title(title,pad=14,loc='left')

def export(fig,name,exclude_axes=None):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig,json_out=A/f'{name}.alignment.json',
        overlay_svg=A/f'{name}.alignment.svg',tolerance_pt=1.5,gutter_tolerance_pt=1.5,
        require_panel_labels=True,strict=True,exclude_axes=exclude_axes or [])
    fig.savefig(O/f'{name}.pdf',dpi=600)
    fig.savefig(O/f'{name}.svg',dpi=600)
    fig.savefig(O/f'{name}.png',dpi=600)
    fig.canvas.draw(); r=fig.canvas.get_renderer(); page=fig.bbox
    clipped=[]
    for t in fig.findobj(mpl.text.Text):
        if t.get_visible() and t.get_text():
            b=t.get_window_extent(r)
            if b.x0<page.x0-.5 or b.y0<page.y0-.5 or b.x1>page.x1+.5 or b.y1>page.y1+.5: clipped.append(t.get_text())
    assert not clipped,clipped
    plt.close(fig)

def load_external_predictions(reference_csv=None, download_reference=False):
    rec=pd.read_csv(S/'external_predictions_and_similarity.csv')
    meta=json.loads((S/'apfe_reference_manifest.json').read_text())
    if download_reference:
        payload=urllib.request.urlopen(meta['source_url'],timeout=30).read()
    elif reference_csv:
        payload=Path(reference_csv).read_bytes()
    else:
        raise ValueError('Figure A requires --download-reference or --reference-csv for the fixed author source')
    assert hashlib.sha256(payload).hexdigest()==meta['source_sha256'],'Author source checksum mismatch'
    ids=set(rec.apfe_id)
    labels={r['ID']:float(r['thermal_conductivity']) for r in csv.DictReader(io.StringIO(payload.decode('utf-8-sig').split('\n',1)[1])) if r['ID'] in ids}
    assert set(labels)==ids and len(labels)==93
    rec['reference']=rec.apfe_id.map(labels)
    rec['residual']=rec.prediction-rec.reference
    rec['absolute_error']=rec.residual.abs()
    return rec

def external(reference_csv=None,download_reference=False):
    dist=pd.read_csv(S/'target_distribution_bins.csv')
    rec=load_external_predictions(reference_csv,download_reference)
    common=pd.read_csv(S/'common_target_interval_comparison.csv')
    seedstats=pd.read_csv(S/'external_seed_diagnostics.csv')
    nearest=pd.read_csv(S/'nearest_actual_training_structures.csv')
    assert len(rec)==930 and rec.groupby(['seed','arm']).size().eq(93).all()
    assert nearest.groupby('seed').size().eq(93).all() and nearest.training_n.eq(3000).all()
    assert np.isfinite(rec[['reference','prediction','residual','absolute_error','nearest_training_tanimoto']]).all().all()
    assert np.allclose(rec.prediction-rec.reference,rec.residual,atol=1e-14)
    assert np.allclose(rec.residual.abs(),rec.absolute_error,atol=1e-14)
    chk=rec.merge(nearest[['seed','apfe_id','nearest_training_tanimoto']],on=['seed','apfe_id'],suffixes=('_record','_nearest'),validate='many_to_one')
    assert np.allclose(chk.nearest_training_tanimoto_record,chk.nearest_training_tanimoto_nearest)
    seed=32101; d=dist[dist.seed.eq(seed)]; e=rec[rec.seed.eq(seed)]; co=common[common.seed.eq(seed)]
    assert (co.sufficient_n_min10_both == (co.internal_n.ge(10)&co.external_n.ge(10))).all()
    fig,axs=plt.subplots(2,2,figsize=(180/25.4,190/25.4))
    fig.subplots_adjust(left=.115,right=.975,bottom=.165,top=.88,wspace=.36,hspace=.72)
    ax=axs[0,0]; x=np.arange(5)
    for cohort,col,mark,display in [('training',GREY,'s','Training'),('internal_evaluation',BLUE,'o','Internal'),('APFE',RUST,'^','APFE')]:
        z=d[d.cohort.eq(cohort)].sort_values('kappa_low'); assert len(z)==5 and z.bin_n.sum()==z.total_n.iloc[0]
        ax.plot(x,z.fraction,color=col,marker=mark,ms=3.8,lw=1,label=f'{display} (N = {z.total_n.iloc[0]})')
    ax.set_xticks(x,['<0.2','0.2–0.3','0.3–0.4','0.4–0.5','≥0.5'],rotation=30,ha='right',rotation_mode='anchor')
    ax.set_ylim(0,1.02); ax.set_yticks([0,.25,.5,.75,1]); ax.set_ylabel('Fraction of records')
    ax.set_xlabel('Reference κ interval (W/(m·K))',labelpad=7)
    ax.legend(loc='upper right',fontsize=7.5,handlelength=1.4,labelspacing=.45)
    label(ax,'a','Target distributions')
    ax=axs[0,1]
    op=e[e.arm.eq('open')].sort_values('apfe_id'); pe=e[e.arm.eq('periodic')].sort_values('apfe_id')
    assert op.apfe_id.tolist()==pe.apfe_id.tolist() and np.allclose(op.reference,pe.reference)
    ax.plot([0,1.15],[0,1.15],ls=(0,(4,3)),color='#555555',lw=.7,zorder=1)
    ax.scatter(op.reference,op.prediction,s=13,facecolors='none',edgecolors=GREY,linewidths=.55,zorder=2)
    norm=TwoSlopeNorm(vmin=-.75,vcenter=0,vmax=.75)
    pts=ax.scatter(pe.reference,pe.prediction,s=14,c=pe.residual,cmap='RdBu_r',norm=norm,linewidths=0,zorder=3)
    ax.set_xlim(0,1.15); ax.set_ylim(0,1.15); ax.set_xticks([0,.4,.8]); ax.set_yticks([0,.4,.8])
    ax.set_xlabel('APFE reference κ (W/(m·K))',labelpad=7); ax.set_ylabel('Predicted κ (W/(m·K))')
    label(ax,'b','External predictions')
    p=ax.get_position(); cax=fig.add_axes([p.x0+.045*p.width,p.y0+.84*p.height,.40*p.width,.035*p.height])
    cb=fig.colorbar(pts,cax=cax,orientation='horizontal',ticks=[-.6,0,.6]); cb.ax.tick_params(labelsize=7,length=2,pad=2)
    cb.ax.set_title('Residual (W/(m·K))',fontsize=7,pad=4); cb.outline.set_linewidth(.5)
    cb.solids.set_rasterized(False)
    ax=axs[1,0]
    ax.scatter(op.nearest_training_tanimoto,op.absolute_error,s=12,facecolors='none',edgecolors=GREY,linewidths=.5,zorder=1)
    ax.scatter(pe.nearest_training_tanimoto,pe.absolute_error,s=13,color=BLUE,linewidths=0,alpha=.85,zorder=2)
    ax.set_xlim(.15,1.03); ax.set_ylim(-.015,.75); ax.set_xticks([.2,.4,.6,.8,1]); ax.set_yticks([0,.2,.4,.6])
    ax.set_xlabel('Nearest training Tanimoto',labelpad=7); ax.set_ylabel('Absolute error (W/(m·K))')
    rho=seedstats[(seedstats.seed.eq(seed))&seedstats.arm.eq('periodic')].iloc[0].spearman_similarity_abs_error
    ax.text(.98,.92,f'Periodic Spearman ρ = {rho:.3f}',transform=ax.transAxes,ha='right',fontsize=7.5)
    label(ax,'c','Similarity to the actual training set')
    ax=axs[1,1]; x=np.arange(4)
    base=co[co.arm.eq('periodic')].sort_values('kappa_low')
    ticks=[]
    for _,row in base.iterrows():
        interval=f'{row.kappa_low:g}–{row.kappa_high:g}' if row.kappa_high<2 else '≥0.4'
        ticks.append(f'{interval}\n{int(row.internal_n)} / {int(row.external_n)}')
    for arm,lw,ls,alpha in [('open',.65,(0,(2,2)),.7),('periodic',1.4,'-',1)]:
        z=co[co.arm.eq(arm)].sort_values('kappa_low')
        for j,(_,row) in enumerate(z.iterrows()):
            if row.sufficient_n_min10_both:
                ax.plot([j-.13,j+.13],[row.internal_mae,row.external_mae],color=BLUE if arm=='periodic' else GREY,lw=lw,ls=ls,alpha=alpha,zorder=2)
                ax.plot(j-.13,row.internal_mae,'o',color=BLUE if arm=='periodic' else GREY,ms=4 if arm=='periodic' else 3,fillstyle='none',zorder=3)
                ax.plot(j+.13,row.external_mae,'^',color=RUST if arm=='periodic' else GREY,ms=4 if arm=='periodic' else 3,fillstyle='full' if arm=='periodic' else 'none',zorder=3)
    for j,(_,row) in enumerate(base.iterrows()):
        if not row.sufficient_n_min10_both:
            ax.text(j,.034,'Insufficient',ha='center',va='center',rotation=90,rotation_mode='anchor',fontsize=7.5,color='#555555')
    ax.set_xlim(-.5,3.5); ax.set_ylim(0,.065); ax.set_yticks([0,.02,.04,.06]); ax.set_xticks(x,ticks)
    ax.set_xlabel('Reference κ interval (W/(m·K))\nN internal / APFE',labelpad=7); ax.set_ylabel('MAE (W/(m·K))')
    label(ax,'d','Common target intervals')
    handles=[Line2D([],[],marker='o',color=BLUE,markerfacecolor='none',lw=0,label='Internal'),Line2D([],[],marker='^',color=RUST,lw=0,label='APFE'),Line2D([],[],color=BLUE,lw=1.4,label='Periodic'),Line2D([],[],color=GREY,lw=.65,ls='--',marker='o',markerfacecolor='none',ms=3,label='Open reference')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.55,.045),ncol=4,columnspacing=1.2,handlelength=1.5,handletextpad=.4,fontsize=7.5)
    fig.text(.115,.975,'APFE cross-source diagnosis',fontsize=9,fontweight='bold')
    fig.text(.115,.943,'Fixed display: seed 32101; 93 APFE items; saved predictions only.',fontsize=8)
    export(fig,'A_external_diagnostics',exclude_axes=[cax])
    (A/'A_data_checks.json').write_text(json.dumps({'status':'PASS','fixed_display_seed':seed,'all_external_predictions':len(rec),'display_external_items':len(pe),'training_n':3000,'internal_n':400,'cross_seed_models_are_not_independent_items':True,'similarity_reference':'actual 3000 training records per seed','common_interval_counts':base[['kappa_low','kappa_high','internal_n','external_n','sufficient_n_min10_both']].to_dict('records'),'new_fit':0,'new_forward':0},indent=2)+'\n')

def budget():
    ci=pd.read_csv(S/'B_conditional_intervals.csv').set_index('contrast')
    ps=pd.read_csv(S/'B_per_seed_paired_differences.csv')
    assert json.loads((S/'B_status.json').read_text())['new600_9400_received']
    assert ci.evaluation_records_per_seed.eq(400).all() and ci.evaluation_clusters.eq(46).all()
    assert ci.valid_draws.eq(5000).all() and ci.empty_draws.eq(0).all()
    schedules={1900:('epochs_600_periodic_minus_open','steps_3000_periodic_minus_open'),
               9400:('steps9400_600_periodic_minus_open','epochs_3000_periodic_minus_open')}
    for names in schedules.values():
        for n in names:
            z=ps[ps.contrast.eq(n)]; assert len(z)==5 and set(z.seed)==set(range(32101,32106))
            assert np.isclose(z.mae_difference.mean(),ci.loc[n,'difference'],atol=1e-14)
    for steps,con in [(1900,'steps1900_3000_minus_600'),(9400,'steps9400_3000_minus_600')]:
        n0,n1=schedules[steps]
        assert np.isclose(ci.loc[n1,'difference']-ci.loc[n0,'difference'],ci.loc[con,'difference'],atol=1e-14)
    interaction='interaction_budget_delta_long_minus_short'
    assert np.isclose(ci.loc['steps9400_3000_minus_600','difference']-ci.loc['steps1900_3000_minus_600','difference'],ci.loc[interaction,'difference'],atol=1e-14)
    fig,axs=plt.subplots(1,2,figsize=(180/25.4,110/25.4))
    fig.subplots_adjust(left=.105,right=.975,bottom=.28,top=.74,wspace=.32)
    plotrows=[]
    for ax in axs:
        ax.axhline(0,color='#555555',lw=.8,ls=(0,(4,3)),zorder=1)
        ax.set_ylim(-2.0,1.65); ax.set_yticks([-2,-1,0,1])
        ax.set_ylabel('MAE difference (mW/(m·K))',labelpad=7)
    ax=axs[0]
    for steps,color,offset,marker in [(1900,BLUE,-.065,'o'),(9400,RUST,.065,'s')]:
        names=schedules[steps]; z=ci.loc[list(names)]
        x=np.arange(2)+offset; center=z.difference.to_numpy()*1000
        lower=z.lower.to_numpy()*1000; upper=z.upper.to_numpy()*1000
        ax.plot(x,center,lw=.8,color=color,zorder=2)
        ax.errorbar(x,center,yerr=[center-lower,upper-center],fmt=marker,ms=4.3,
            color=color,elinewidth=1,capsize=3,capthick=.8,zorder=3,label=f'{steps:,} updates')
        for n in names: plotrows.append({'panel':'a','contrast':n,**ci.loc[n].to_dict()})
    ax.set_xlim(-.4,1.4);ax.set_xticks([0,1],['600','3,000']);ax.set_xlabel('Training labels',labelpad=7)
    label(ax,'a','ΔN = Periodic − Open')
    ax=axs[1]
    contrasts=['steps1900_3000_minus_600','steps9400_3000_minus_600',interaction]
    for j,(con,col,mark) in enumerate(zip(contrasts,[BLUE,RUST,GREY],['o','s','D'])):
        row=ci.loc[con]; center=row.difference*1000
        ax.errorbar(j,center,yerr=[[center-row.lower*1000],[row.upper*1000-center]],fmt=mark,
            ms=4.3,color=col,elinewidth=1,capsize=3,capthick=.8,zorder=3)
        plotrows.append({'panel':'b','contrast':con,**row.to_dict()})
    ax.set_xlim(-.45,2.45);ax.set_xticks([0,1,2],['1,900','9,400','Long − short'])
    ax.set_xlabel('Update schedule / interaction',labelpad=7)
    label(ax,'b','Δ3000 − Δ600 and its change')
    fig.text(.105,.965,'Representation effect across label and optimization budgets',fontsize=9,fontweight='bold')
    fig.legend(handles=[Line2D([],[],marker='o',color=BLUE,lw=.8,label='1,900-update schedule'),Line2D([],[],marker='s',color=RUST,lw=.8,label='9,400-update schedule')],
        loc='upper center',bbox_to_anchor=(.54,.90),ncol=2,handletextpad=.5,columnspacing=1.6)
    fig.text(.105,.14,'Points: mean of five paired runs; intervals: conditional 95% cluster bootstrap.',fontsize=8)
    fig.text(.105,.08,'400 records per seed; 46 shared clusters; learning-rate paths differ by schedule.',fontsize=8)
    export(fig,'B_budget_representation_effects')
    pd.DataFrame(plotrows).to_csv(O/'B_plotted_effects.csv',index=False)
    (A/'B_data_checks.json').write_text(json.dumps({'status':'PASS','runs':5,'records_per_seed':400,'evaluation_unique_records':1738,'shared_evaluation_clusters':46,'bootstrap_draws':5000,'interval':'pointwise percentile conditional 95%; fixed fits; no retraining uncertainty','direct_delta_arithmetic_pass':True,'long_schedule_DID_crosses_zero':True,'interaction_crosses_zero':True,'new_fit':0,'new_forward':0},indent=2)+'\n')

def target_tradeoffs():
    pm=pd.read_csv(S/'A_per_seed_metrics.csv')
    ci=pd.read_csv(S/'A_conditional_intervals.csv')
    loo=pd.read_csv(S/'A_leave_one_high_cluster_means_11_each.csv')
    tk=pd.read_csv(S/'A_topK_actual_hits_summary.csv')
    td=pd.read_csv(S/'A_topK_paired_differences_per_seed.csv')
    assert len(pm)==15 and pm.n.eq(600).all() and pm.high_n.eq(39).all() and pm.high_clusters.eq(11).all()
    assert set(pm.seed)==set(range(43101,43106)) and set(pm.arm)=={'mse','q90_weight2','multitask'}
    assert len(loo)==22 and loo.removed_cluster.nunique()==11 and loo.remaining_high_clusters.eq(10).all()
    for con,other in [('multitask_minus_mse','mse'),('multitask_minus_q90_weight2','q90_weight2')]:
        for endpoint in ['mae','high_mae']:
            p=pm.pivot(index='seed',columns='arm',values=endpoint)
            row=ci[(ci.contrast.eq(con))&ci.endpoint.eq(endpoint)].iloc[0]
            assert np.isclose((p.multitask-p[other]).mean(),row.difference,atol=1e-14)
    fig,axs=plt.subplots(2,2,figsize=(180/25.4,190/25.4))
    fig.subplots_adjust(left=.115,right=.975,bottom=.18,top=.865,wspace=.36,hspace=.65)
    arms=['mse','q90_weight2','multitask']; colors=[GREY,RUST,BLUE]
    for ax,endpoint,letter,title in [(axs[0,0],'mae','a','Overall evaluation MAE'),(axs[0,1],'high_mae','b','High-value evaluation MAE')]:
        wide=pm.pivot(index='seed',columns='arm',values=endpoint)[arms]*1000
        for k,(seed,row) in enumerate(wide.iterrows()):
            # Small seed-specific horizontal offsets preserve repeated points and pairing.
            offset=(k-2)*.028
            ax.plot(np.arange(3)+offset,row.values,color='#C2C2C2',lw=.65,zorder=1)
            for j,col in enumerate(colors):ax.plot(j+offset,row.values[j],'o',ms=3.7,color=col,zorder=2)
        for j,col in enumerate(colors):
            ax.plot([j-.12,j+.12],[wide.iloc[:,j].mean()]*2,color=col,lw=2,zorder=3)
        ax.set_xlim(-.4,2.4);ax.set_xticks([0,1,2],['MSE','Weighted','Multitask'])
        ax.set_ylabel('MAE (mW/(m·K))',labelpad=7)
        if endpoint=='mae':ax.set_ylim(17.2,19.4);ax.set_yticks([17.5,18,18.5,19])
        else:ax.set_ylim(38,58);ax.set_yticks([40,45,50,55])
        label(ax,letter,title)
    ax=axs[1,0]
    clusters=sorted(loo.removed_cluster.unique()); x=np.arange(len(clusters))
    ax.axhline(0,color='#555555',lw=.8,ls=(0,(4,3)),zorder=1)
    for con,col,marker,display,off in [('multitask_minus_mse',BLUE,'o','Multitask − MSE',-.07),('multitask_minus_q90_weight2',RUST,'s','Multitask − Weighted',.07)]:
        z=loo[loo.contrast.eq(con)].set_index('removed_cluster').loc[clusters]
        ax.plot(x+off,z.high_mae_difference*1000,color=col,marker=marker,ms=3.3,lw=.65,label=display,zorder=2)
    ax.set_xlim(-.6,10.6);ax.set_ylim(-3.3,.6);ax.set_yticks([-3,-2,-1,0]);ax.set_xticks(x,[str(int(k)) for k in clusters],rotation=55,ha='right',rotation_mode='anchor',fontsize=7.5)
    ax.set_ylabel('High-value ΔMAE (mW/(m·K))',labelpad=7)
    ax.set_xlabel('Removed high-value cluster',labelpad=7)
    ax.legend(loc='lower left',fontsize=7.2,handlelength=1.2,handletextpad=.4,labelspacing=.3)
    label(ax,'c','Leave-one-cluster-out sensitivity')
    ax=axs[1,1];ks=[10,20,50,100]; x=np.arange(4)
    ax.axhline(0,color='#555555',lw=.8,ls=(0,(4,3)),zorder=1)
    plotrows=[]
    series=[('q90_weight2_regression_minus_mse_regression',RUST,'s',-.16,'Weighted regression'),('multitask_regression_minus_mse_regression',BLUE,'o',0,'Multitask regression'),('multitask_classification_minus_mse_regression',BLUE,'^',.16,'Multitask classification')]
    for contrast,col,marker,off,display in series:
        z=ci[(ci.contrast.eq(contrast))&ci.endpoint.isin([f'top{k}_hit_count' for k in ks])].set_index('endpoint').loc[[f'top{k}_hit_count' for k in ks]]
        center=z.difference.to_numpy();lower=z.lower.to_numpy();upper=z.upper.to_numpy()
        for j,k in enumerate(ks):
            rows=td[(td.contrast.eq(contrast))&td.k.eq(k)]; assert len(rows)==5
            assert np.isclose(rows.hit_difference.mean(),center[j],atol=1e-14)
            ar='q90_weight2' if contrast.startswith('q90') else 'multitask';head='classification_logit' if 'classification' in contrast else 'regression'
            ma=tk[(tk.arm.eq(ar))&tk.ranking.eq(head)&tk.k.eq(k)].iloc[0]
            mb=tk[(tk.arm.eq('mse'))&tk.k.eq(k)].iloc[0]
            assert np.isclose(ma.mean_hits-mb.mean_hits,center[j],atol=1e-14)
            plotrows.append({'contrast':contrast,'k':k,'mean_hit_difference':center[j],'lower':lower[j],'upper':upper[j],'mean_hits_method':ma.mean_hits,'mean_hits_MSE':mb.mean_hits})
        ax.errorbar(x+off,center,yerr=[center-lower,upper-center],fmt=marker,ms=3.5,
            color=col,markerfacecolor='white' if marker=='^' else col,elinewidth=.8,capsize=2,capthick=.65,zorder=2,label=display)
    ax.set_xlim(-.5,3.5);ax.set_ylim(-10,4);ax.set_yticks([-10,-5,0]);ax.set_xticks(x,['10','20','50','100'])
    ax.set_ylabel('Mean hit difference versus MSE',labelpad=7);ax.set_xlabel('Top-K',labelpad=7)
    label(ax,'d','Ranking overlap with true Top-K')
    fig.legend(handles=[Line2D([],[],marker=m,color=c,markerfacecolor='white' if m=='^' else c,lw=0,label=d) for _,c,m,_,d in series],loc='lower center',bbox_to_anchor=(.55,.04),ncol=3,fontsize=7.2,handletextpad=.3,columnspacing=1.1)
    fig.text(.115,.975,'Target trade-offs at 3,000 training labels',fontsize=9,fontweight='bold')
    fig.text(.115,.942,'Evaluation: 600 records / 24 clusters; κ ≥ 0.30: 39 records / 11 clusters.',fontsize=8)
    fig.text(.115,.910,'a,b: five paired runs; short bars: means. d: conditional 95% cluster intervals.',fontsize=8)
    export(fig,'C_target_tradeoffs')
    pd.DataFrame(plotrows).to_csv(O/'C_ranking_plotted_effects.csv',index=False)
    (A/'C_data_checks.json').write_text(json.dumps({'status':'PASS','training_labels':3000,'evaluation_records':600,'evaluation_clusters':24,'high_threshold_W_mK':.30,'high_records':39,'high_clusters':11,'five_paired_runs':list(range(43101,43106)),'leave_one_cluster_out':11,'topK':[10,20,50,100],'ranking_3_outputs_checked_against_actual_hit_counts':True,'new_fit':0,'new_forward':0},indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--figure',choices=['A','B','C','all'],default='A'); p.add_argument('--source-dir',type=Path); p.add_argument('--output-dir',type=Path); p.add_argument('--reference-csv',type=Path); p.add_argument('--download-reference',action='store_true'); args=p.parse_args()
    if args.source_dir: S=args.source_dir.resolve()
    if args.output_dir: O=args.output_dir.resolve(); A=O/'audit'
    O.mkdir(parents=True,exist_ok=True); A.mkdir(parents=True,exist_ok=True)
    if args.figure in ['A','all']:external(args.reference_csv,args.download_reference)
    if args.figure in ['B','all']:budget()
    if args.figure in ['C','all']:target_tradeoffs()
