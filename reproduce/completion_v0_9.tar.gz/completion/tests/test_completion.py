"""Adversarial checks plus one unrelated-directory end-to-end replay.
No fitting or forward passes. Two checkpoint reloads are a schema smoke test.
"""
import copy,importlib.util,json,os,shutil,subprocess,sys,tempfile,unittest
from pathlib import Path
BASE=Path(__file__).resolve().parents[1];REPO=BASE.parents[1]
sys.path.insert(0,str(BASE))
import integrity

class CompletionTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory(prefix='completion-clean-tests-');cls.clean=Path(cls.temp.name)/'clean';cls.module=cls.clean/'reproduce/completion'
  shutil.copytree(BASE,cls.module,ignore=shutil.ignore_patterns('__pycache__'))
  for rel in ('polymer_dmpnn/graph.py','polymer_dmpnn/paper.py','polymer_dmpnn/__init__.py','reproduce/inputs/records.csv.gz','reproduce/inputs/splits.json'):
   dest=cls.clean/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/rel,dest)
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def test_01_unrelated_directory_replay(self):
  output=Path(self.temp.name)/'replayed';env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
  r=subprocess.run([sys.executable,str(self.module/'replay.py'),'--output',str(output)],cwd=self.temp.name,env=env,capture_output=True,text=True)
  self.assertEqual(r.returncode,0,r.stdout+'\n'+r.stderr);v=json.loads((output/'verification.json').read_text());self.assertEqual(v['status'],'PASS');self.assertEqual(v['new_models'],25);self.assertGreaterEqual(v['paired_analysis_files_recomputed'],14);self.assertEqual(v['fit'],0);self.assertEqual(v['forward'],0)
 def test_02_source_change_rejected(self):
  file=self.module/'paired_math.py';data=file.read_bytes()
  try:
   file.write_bytes(data+b'\n# changed\n')
   with self.assertRaisesRegex(ValueError,'SOURCE_OR_RESOURCE_CHANGED'):integrity.verify_package(self.module)
  finally:file.write_bytes(data)
 def test_03_nonfinite_prediction_rejected(self):
  groups={('cohort',1,'open'):[{'record_id':'a','truth':.2,'prediction':float('nan'),'cluster_id':'c'}]}
  with self.assertRaisesRegex(ValueError,'NONFINITE'):integrity.validate_pairing(groups)
 def test_04_paired_truth_shift_rejected(self):
  groups={('cohort',1,'open'):[{'record_id':'a','truth':.2,'prediction':.21,'cluster_id':'c'}],('cohort',1,'periodic'):[{'record_id':'a','truth':.3,'prediction':.22,'cluster_id':'c'}]}
  with self.assertRaisesRegex(ValueError,'PAIRED_TRUTH'):integrity.validate_pairing(groups)
 def test_05_missing_model_rejected(self):
  f=next((self.module/'weights').glob('*.pt'));original=f.read_bytes();f.unlink()
  try:
   with self.assertRaisesRegex(ValueError,'MISSING_RESOURCE'):integrity.verify_package(self.module)
  finally:f.write_bytes(original)
 def test_06_default_training_is_target_blind_dry_run(self):
  r=subprocess.run([sys.executable,str(self.module/'retrain_budget.py')],cwd=self.temp.name,capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr);x=json.loads(r.stdout);self.assertEqual(x['fits_started'],0);self.assertEqual(x['forwards'],0);self.assertEqual(x['target_values_read'],0);self.assertEqual(x['fits_planned'],10);self.assertEqual(x['configuration']['warmup_steps'],376);self.assertEqual(x['configuration']['last_epoch_observations'],224)
 def test_07_two_checkpoint_schema_reloads_without_forward(self):
  from predict import load_model
  for mid in ('budget_32101_open','hk01_43101_multitask'):
   model,spec=load_model(mid);self.assertEqual(sum(p.numel() for p in model.parameters()),spec['parameters']);self.assertFalse(model.training)
 def test_08_missing_pair_rejected(self):
  with self.assertRaisesRegex(ValueError,'MISSING_OR_UNEXPECTED_MODEL_GROUP'):integrity.validate_pairing({},required_groups={('cohort',1,'open')})

if __name__=='__main__':unittest.main()
