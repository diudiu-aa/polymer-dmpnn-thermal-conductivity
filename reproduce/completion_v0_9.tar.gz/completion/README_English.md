# Controlled completion: record replay, exact checkpoints and core retraining

This independent supplement preserves the original Tables 1–5, default predictor, older checkpoints and existing replay semantics. It evaluates controlled representation, label-budget, optimization-schedule and objective tradeoffs; it does not claim a newly invented periodic graph architecture.

Use Python 3.10–3.13. All resources resolve relative to the package; `--output` controls new results. A repository checkout is required, including the existing shared `polymer_dmpnn` implementation and `reproduce/inputs`. No private project directory is required.

```bash
python -m pip install numpy
python reproduce/completion/replay.py --output reproduced-completion
```

The output directory must not already exist. The command verifies code, compressed inputs and 25 checkpoint hashes, then recomputes per-record metrics for 15 HK01 objective fits and 10 new 600-label/9400-update fits. It also recomputes all 11 high-cluster deletion checks, multitask-versus-weighted comparisons, actual Top-K overlap counts, paired cluster intervals, representation differences, budget differences-in-differences and label-by-schedule interactions. Existing 600/1900, 1800/5650, 3000/1900 and 3000/9400 predictions are bundled as the required small scale subset. Reference tables are used only to check freshly computed values, never copied as the result.

The 5000 draws use NumPy `default_rng(2026102907)`. Intervals are pointwise conditional percentile 95% intervals with no multiplicity adjustment; they condition on the fixed fitted models and observed cohort, excluding retraining uncertainty. HK01 has a shared 600-record/24-cluster cohort, including 39 records in 11 clusters at κ≥0.30. The budget design has 400 records per seed and a shared set of 46 clusters; record identities differ across seeds. The same cluster weights are applied across settings/arms/seeds, each seed keeps its own record-weighted denominator, and the five estimates are then averaged. Seed SD is sample SD, not a population confidence interval.

Top-K measures overlap of predicted and reference Top-K sets. Classification and regression rankings are separate. Exploratory ranking intervals re-rank the paired cluster multiset with repeated records retained as copies and K fixed; these are not independent-candidate success-rate intervals. HK01 uses record-ID order for stable ties. The second-partition open arm was added after earlier scoring. HK01 evaluation identities come from a historical training pool and may have participated in earlier development. Freezing current predictions does not erase that history. This is retrospective same-source MD evaluation, not blind, experimental or independent-source validation. All adverse outcomes are retained, including worse mean MAE after the longer 600-label schedule.

Install the repository's scientific dependencies to use one exact checkpoint:

```bash
python -m pip install .
python reproduce/completion/predict.py --list-models
python reproduce/completion/predict.py --model-id hk01_43101_multitask --smiles-json reproduce/completion/example_smiles.json --output predictions.json
```

The 25 original checkpoint files are copied byte-for-byte. `registry.json` registers their source receipts, architecture, normalization, role resources and SHA256. One selected seed/model is used, without ensembling or fitting. The original `MultitaskDMPNN` class also returns an uncalibrated classification logit, not a calibrated probability.

Core budget retraining is explicit and defaults to a target-blind dry-run:

```bash
python reproduce/completion/retrain_budget.py
python reproduce/completion/retrain_budget.py --run --seed 32101 --arm periodic --output retrained-budget-one
```

`--seed all --arm both` requests all ten budget fits. The exact original public 600/400 roles/order, L3/D3/hidden128/dropout0.1/batch16, Adam defaults and own-600 population mean/SD are retained. Initialization uses seed, permutation seed+10000, dropout seed+20000. The update-aligned schedule warms for 376 steps from 1e-4 to 1e-3 and exponentially decays to 1e-4 at update9400. With 38 batches/epoch, training retains the final 14 batches/224 observations after 247 complete epochs, totaling148424 observations. The terminal checkpoint is fixed; no evaluation-driven selection occurs.

Retraining hard timers require POSIX (macOS/Linux); saved-result replay does not use those timers. CPU threads=1; hard limits are300 seconds/fit and2400 seconds total, with at most10 fits. Identity, graph, nonfinite or timeout failures preserve artifacts and stop without automatic retry. The command saves new curves, weights and400 predictions without reading numerical evaluation targets. The comparison changes optimization budget and learning-rate schedule together; it is not a pure update-count effect. Only core budget retraining is supported here. HK01, historical searches and the full raw-to-curated pipeline are not claimed as independently retrainable by this module.

Figure source tables and portable plotting instructions are in `figures/README.md` when the finalized figure assets are included. Individual APFE references are not redistributed. External plotting must fetch or receive the fixed author CSV used by `reproduce/apfe`, checking its SHA. Our predictions/nearest-neighbor scores and aggregate diagnostics may be archived.

```bash
python -m unittest discover -s reproduce/completion/tests -v
```

Tests run a clean temporary-directory replay and remove it, reject modified source, nonfinite predictions, shifted paired truth, missing models/pairs, and check the default dry-run. Two checkpoint reloads check schema without fitting or forwarding. `verification.json` distinguishes saved-record replay from inference and retraining.

Software and trained weights retain the repository's MIT license. PolyOmics source-derived records/references remain CC BY4.0 with full attribution; they are not relabeled as MIT. See this directory's `THIRD_PARTY_DATA.md` and the repository's provenance notice.
