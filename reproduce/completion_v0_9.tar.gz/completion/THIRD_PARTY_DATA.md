# PolyOmics attribution and changes

Source-derived thermal-conductivity reference labels, original source UUIDs and polymer identity/structure excerpts in this module originate from **Yoshihiro Hayashi and the PolyOmics/RadonPy contributors**, [PolyOmics](https://huggingface.co/datasets/yhayashi1986/PolyOmics), DOI [10.57967/hf/7475](https://doi.org/10.57967/hf/7475), fixed revision `041e5834ea1a48682fae12dc39ccd723bcd4f771`.

The source data card at that revision states [Creative Commons Attribution4.0 International](https://creativecommons.org/licenses/by/4.0/): [fixed-revision data card](https://huggingface.co/datasets/yhayashi1986/PolyOmics/blob/041e5834ea1a48682fae12dc39ccd723bcd4f771/README.md). Preserve these attribution, license and modification notices when redistributing the source-derived excerpts. The software MIT license does not replace the source-data license.

Changes made in this work: selection of fixed training/evaluation subsets; canonical/graph identity and isolation-group assignment; structural clustering; preservation of original UUIDs; addition of model predictions, classifier logits, training-role metadata and aggregate diagnostics; compression and reproducibility packaging. The included simulation references describe nominally unstretched amorphous bulk near300K/1atm in W/(mK), not new experimental measurements. Repeated observations and historical role use are not relabeled as independent materials or blind validation.

The package is a curated excerpt, not the complete database. It excludes protected historical test data, PoLyInfo exports, restricted experimental labels, author PDFs and private logs. Our trained weights and software are covered by the repository MIT license, separately from source-derived records and labels.

# APFE data boundary

Do not redistribute individual APFE author references through this module. Only our predictions, candidate IDs, derived nearest-neighbor scores and aggregate diagnostics may be bundled. Any external-reference plot must obtain the exact public author CSV through the fixed source recorded by `reproduce/apfe`, validating its checksum. Cite Huang etal., Journal of Materials ChemistryA2023, DOI [10.1039/D3TA03370H](https://doi.org/10.1039/D3TA03370H), and the relevant RadonPy work. The author repository's software license is not asserted to license its underlying data. See [the existing APFE documentation](../apfe/README.md) and the repository [data provenance notice](../../THIRD_PARTY_DATA.md).
