"""Retrospective paired analyses of existing scored predictions only.

No model imports, fits, checkpoint loads, forwards, or parent label-table reads.
Run with Python >=3.10 and NumPy. All outputs stay beside this script.
"""
from pathlib import Path
from collections import defaultdict
import argparse, csv, gzip, hashlib, json, math, platform
import numpy as np

OUT = Path('.')
ROOT = Path('.')
HK = ROOT/'hk'
REPRO = ROOT/'reproduction'
V2 = ROOT/'v2'
B = 5000
RNG_SEED = 2026102907
SOURCES = {}
CHECKS = []

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def source(p):
    p = Path(p).resolve()
    SOURCES[str(p.relative_to(ROOT))] = sha(p)
    return p
def js(p): return json.loads(source(p).read_text())
def rows(p):
    p = source(p)
    with (gzip.open(p, 'rt', newline='') if p.suffix == '.gz' else p.open(newline='')) as f:
        return list(csv.DictReader(f))
def save(name, data): (OUT/name).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
def table(name, data):
    if not data: return
    keys = list(dict.fromkeys(k for r in data for k in r))
    with (OUT/name).open('w', newline='') as f:
        w = csv.DictWriter(f, keys); w.writeheader(); w.writerows(data)
def check(condition, message):
    if not condition: raise ValueError(message)
    CHECKS.append(message)
def ci(values, point, **extra):
    v = np.asarray(values); v = v[np.isfinite(v)]
    q = np.quantile(v, [.025,.975])
    return dict(**extra, difference=float(point), lower=float(q[0]), upper=float(q[1]),
                valid_draws=len(v), empty_draws=B-len(v), requested_draws=B,
                interval='pointwise percentile 95%; conditional on fixed fits/cohort protocol')
def cluster_draws(cl):
    clusters = sorted(set(cl)); lookup = {c:i for i,c in enumerate(clusters)}
    ix = np.array([lookup[c] for c in cl]); nc = len(clusters)
    draws = np.random.default_rng(RNG_SEED).integers(0, nc, size=(B,nc))
    weights = np.array([np.bincount(d, minlength=nc) for d in draws])
    return clusters, ix, weights
def boot_record_delta(delta, mask, ix, weights):
    ncl = weights.shape[1]
    sums = np.bincount(ix[mask], weights=delta[mask], minlength=ncl)
    counts = np.bincount(ix[mask], minlength=ncl)
    den = weights @ counts; num = weights @ sums
    return np.divide(num, den, out=np.full(B,np.nan), where=den>0)
def rank_hits(y, scores, k):
    # Arrays are in record-ID order; stable ties therefore use record ID.
    t = np.argsort(-y, kind='stable')[:k]
    p = np.argsort(-scores, kind='stable')[:k]
    return int(len(set(t)&set(p)))

def analyze_high():
    protocol = js(HK/'protocol.json'); lock = js(HK/'prediction_lock.json')
    check(lock['protocol_sha256']==sha(HK/'protocol.json'), 'HK protocol matches frozen prediction lock')
    identity_rows = rows(HK/'identities.csv'); identity = {r['record_id']:r for r in identity_rows}
    check(len(identity)==len(identity_rows), 'HK identity table has unique record IDs')
    check(protocol['identity_sha256']==sha(HK/'identities.csv'), 'HK identities match protocol hash')
    rr = rows(HK/'scored_predictions.csv'); seeds=protocol['seeds']; arms=protocol['arms']
    grouped=defaultdict(dict)
    for r in rr:
        key=(int(r['seed']),r['arm']); rid=r['record_id']
        check(rid not in grouped[key], f'HK unique {key}/{rid}')
        grouped[key][rid]=r
    ids=sorted(protocol['evaluation_ids']); ref=grouped[seeds[0],arms[0]]
    check(set(grouped)=={(s,a) for s in seeds for a in arms} and len(rr)==9000,'HK exactly 15 scored groups /9000 predictions')
    y=np.array([float(ref[i]['truth']) for i in ids]); cl=np.array([ref[i]['cluster_id'] for i in ids])
    check(len(ids)==600 and len(set(ids))==600, 'HK exactly 600 unique frozen evaluation IDs')
    high=y>=.30; check(int(high.sum())==39 and len(set(cl[high]))==11, 'HK high endpoint is 39 records in 11 clusters')
    check(np.isfinite(y).all(), 'HK truth finite')
    pred={}; classifier={}
    receipts={(r['seed'],r['arm']):r for r in lock['runs']}
    for seed in seeds:
        for arm in arms:
            d=grouped[seed,arm]
            check(set(d)==set(ids), f'HK complete cohort seed {seed} arm {arm}')
            check(all(float(d[i]['truth'])==y[j] and d[i]['cluster_id']==cl[j] for j,i in enumerate(ids)), f'HK exact label/cluster pairing {seed}/{arm}')
            check(all(identity[i]['cluster_id']==cl[j] for j,i in enumerate(ids)), f'HK identity table cluster pairing {seed}/{arm}')
            pred[seed,arm]=np.array([float(d[i]['prediction']) for i in ids])
            check(np.isfinite(pred[seed,arm]).all(), f'HK finite predictions {seed}/{arm}')
            # Verify frozen raw prediction receipt, without reading checkpoints.
            f=HK/f'{seed}_{arm}/predictions.csv'
            rawrows=rows(f); raw={r['record_id']:r for r in rawrows}
            check(sha(f)==receipts[seed,arm]['prediction_sha256'], f'HK raw prediction frozen hash {seed}/{arm}')
            check(len(rawrows)==len(ids) and set(raw)==set(ids), f'HK raw prediction cohort {seed}/{arm}')
            check(all(float(raw[i]['prediction'])==pred[seed,arm][j] for j,i in enumerate(ids)), f'HK scored/raw exact prediction pairing {seed}/{arm}')
            if arm=='multitask':
                classifier[seed]=np.array([float(raw[i]['classifier_score']) for i in ids])
                check(np.isfinite(classifier[seed]).all(), f'HK finite classifier logits {seed}')
    metrics=[]; rank=[]; paired=[]; loco=[]
    pairs=[('multitask','mse'),('multitask','q90_weight2'),('q90_weight2','mse')]
    metrics_by={}
    for seed in seeds:
        for arm in arms:
            err=pred[seed,arm]-y
            r=dict(seed=seed,arm=arm,n=600,clusters=len(set(cl)),high_n=39,high_clusters=11,
                   mae=float(abs(err).mean()),bias=float(err.mean()),high_mae=float(abs(err[high]).mean()),high_bias=float(err[high].mean()))
            metrics.append(r);metrics_by[seed,arm]=r
            for k in (10,20,50,100):
                hit=rank_hits(y,pred[seed,arm],k)
                rank.append(dict(seed=seed,arm=arm,ranking='regression',k=k,hits=hit,proportion=hit/k,denominator=k))
                if arm=='multitask':
                    hit=rank_hits(y,classifier[seed],k)
                    rank.append(dict(seed=seed,arm=arm,ranking='classification_logit',k=k,hits=hit,proportion=hit/k,denominator=k))
        for a,b in pairs:
            paired.append(dict(seed=seed,contrast=f'{a}_minus_{b}',**{k:metrics_by[seed,a][k]-metrics_by[seed,b][k] for k in ('mae','bias','high_mae','high_bias')}))
    for removed in sorted(set(cl[high])):
        mask=high & (cl!=removed)
        for a,b in pairs[:2]:
            per=[]
            for seed in seeds:
                ea=pred[seed,a]-y;eb=pred[seed,b]-y
                r=dict(removed_cluster=removed,removed_high_n=int((high & (cl==removed)).sum()),remaining_high_n=int(mask.sum()),remaining_high_clusters=10,seed=seed,contrast=f'{a}_minus_{b}',
                       high_mae_a=float(abs(ea[mask]).mean()),high_mae_b=float(abs(eb[mask]).mean()),high_bias_a=float(ea[mask].mean()),high_bias_b=float(eb[mask].mean()),
                       high_mae_difference=float((abs(ea[mask])-abs(eb[mask])).mean()),high_bias_difference=float((ea[mask]-eb[mask]).mean()))
                per.append(r);loco.append(r)
            loco.append(dict(removed_cluster=removed,removed_high_n=int((high & (cl==removed)).sum()),remaining_high_n=int(mask.sum()),remaining_high_clusters=10,seed='mean_of_five',contrast=f'{a}_minus_{b}',
                             **{k:float(np.mean([r[k] for r in per])) for k in ('high_mae_a','high_mae_b','high_bias_a','high_bias_b','high_mae_difference','high_bias_difference')}))
    clusters,ix,weights=cluster_draws(cl); intervals=[]
    for a,b in pairs:
        err_a=np.array([pred[s,a]-y for s in seeds]);err_b=np.array([pred[s,b]-y for s in seeds])
        for endpoint in ('mae','high_mae','bias','high_bias'):
            mask=high if endpoint.startswith('high') else np.ones(len(y),bool)
            delta=(abs(err_a)-abs(err_b)).mean(axis=0) if 'mae' in endpoint else (err_a-err_b).mean(axis=0)
            intervals.append(ci(boot_record_delta(delta,mask,ix,weights),delta[mask].mean(),contrast=f'{a}_minus_{b}',endpoint=endpoint,cohort_records=600,resampled_clusters=len(clusters),endpoint_records=int(mask.sum()),endpoint_clusters=len(set(cl[mask]))))
    # Resample one evaluation-cluster multiset across every arm and all five runs.
    # Re-rank each resampled candidate multiset (all copies retained). This is a
    # secondary, pointwise, conditional ranking interval; it is not a hit-rate CI
    # for independent candidates or independent repetitions of training.
    methods=['mse_regression','q90_weight2_regression','multitask_regression','multitask_classification']
    scorearr=np.array([[pred[s,'mse'],pred[s,'q90_weight2'],pred[s,'multitask'],classifier[s]] for s in seeds])
    bootrank=np.full((B,5,4,4),np.nan)
    for bi,w in enumerate(weights):
        sel=np.repeat(np.arange(len(ids)),w[ix])
        if len(sel)<100: continue
        # Equal IDs/copies retain deterministic order in both true and score ranks.
        truth_order=np.argsort(-y[sel],kind='stable')
        for si in range(5):
            for mi in range(4):
                order=np.argsort(-scorearr[si,mi,sel],kind='stable')
                for ki,k in enumerate((10,20,50,100)):
                    tc=np.bincount(sel[truth_order[:k]],minlength=len(ids));pc=np.bincount(sel[order[:k]],minlength=len(ids))
                    bootrank[bi,si,mi,ki]=np.minimum(tc,pc).sum()
    rankpairs=[(2,0),(2,1),(1,0),(3,1),(3,0),(3,2)]
    rankdiff=[]
    for ai,bi in rankpairs:
        an,bn=methods[ai],methods[bi]
        def match(name,s,k):
            arm,typ=name.rsplit('_',1)
            ranking='classification_logit' if typ=='classification' else 'regression'
            return next(r['hits'] for r in rank if r['seed']==s and r['arm']==arm and r['ranking']==ranking and r['k']==k)
        for ki,k in enumerate((10,20,50,100)):
            dd=[]
            for seed in seeds:
                av=match(an,seed,k);bv=match(bn,seed,k);dd.append(av-bv)
                rankdiff.append(dict(seed=seed,contrast=f'{an}_minus_{bn}',k=k,hits_a=av,hits_b=bv,hit_difference=av-bv,proportion_difference=(av-bv)/k))
            z=ci((bootrank[:,:,ai,ki]-bootrank[:,:,bi,ki]).mean(axis=1),np.mean(dd),contrast=f'{an}_minus_{bn}',endpoint=f'top{k}_hit_count',cohort_records=600,resampled_clusters=len(clusters),endpoint_records=k,endpoint_clusters='cohort_reranked')
            intervals.append(z)
            intervals.append({**z,'endpoint':f'top{k}_overlap_proportion','difference':z['difference']/k,'lower':z['lower']/k,'upper':z['upper']/k})
    ranksummary=[]
    for arm,ranking in sorted(set((r['arm'],r['ranking']) for r in rank)):
        for k in (10,20,50,100):
            rr=[r for r in rank if r['arm']==arm and r['ranking']==ranking and r['k']==k]
            ranksummary.append(dict(arm=arm,ranking=ranking,k=k,total_hits_over_five_runs=sum(r['hits'] for r in rr),total_candidate_slots=5*k,mean_hits=float(np.mean([r['hits'] for r in rr])),hit_seed_sd=float(np.std([r['hits'] for r in rr],ddof=1)),mean_proportion=float(np.mean([r['proportion'] for r in rr])),proportion_seed_sd=float(np.std([r['proportion'] for r in rr],ddof=1))))
    table('A_per_seed_metrics.csv',metrics);table('A_per_seed_paired_differences.csv',paired)
    summary=[]
    for arm in arms:
        rr=[r for r in metrics if r['arm']==arm]
        for endpoint in ('mae','bias','high_mae','high_bias'):
            vv=[r[endpoint] for r in rr]
            summary.append(dict(arm=arm,endpoint=endpoint,mean=float(np.mean(vv)),seed_sd=float(np.std(vv,ddof=1)),paired_runs=5,sd_scope='run-to-run sample SD; not population CI'))
    table('A_summary_metrics.csv',summary)
    table('A_leave_one_high_cluster_per_seed_and_mean.csv',loco)
    table('A_leave_one_high_cluster_means_11_each.csv',[r for r in loco if r['seed']=='mean_of_five'])
    table('A_topK_actual_hits_per_seed.csv',rank);table('A_topK_actual_hits_summary.csv',ranksummary)
    table('A_topK_paired_differences_per_seed.csv',rankdiff);table('A_conditional_intervals.csv',intervals)
    losummary=[]
    for a,b in pairs[:2]:
        rr=[r for r in loco if r['seed']=='mean_of_five' and r['contrast']==f'{a}_minus_{b}']
        for endpoint in ('high_mae_difference','high_bias_difference'):
            vals=[r[endpoint] for r in rr]
            losummary.append(dict(contrast=f'{a}_minus_{b}',endpoint=endpoint,min=min(vals),max=max(vals),negative_count=sum(v<0 for v in vals),zero_count=sum(v==0 for v in vals),positive_count=sum(v>0 for v in vals),deleted_clusters=11))
    table('A_leave_one_high_cluster_ranges.csv',losummary)
    return dict(metrics=metrics,intervals=intervals,ranksummary=ranksummary,loco_ranges=losummary,
                identity=dict(records=600,clusters=len(clusters),high_records=39,high_clusters=11,seeds=seeds,labels_exact_across_15_groups=True))

def load_budget():
    manifest=js(REPRO/'manifest.json')
    f=REPRO/'data/predictions.csv.gz'
    check(sha(f)==manifest['files']['data/predictions.csv.gz'], 'Budget portable prediction bundle matches manifest')
    rr=rows(f); groups=defaultdict(dict)
    for r in rr:
        if not r['group'].startswith('scale/'): continue
        rid=r['record_id']; check(rid not in groups[r['group']], f'Budget unique {r["group"]}/{rid}')
        groups[r['group']][rid]=r
    seeds=list(range(32101,32106));ids={s:sorted(groups[f'scale/epochs/600/open/{s}']) for s in seeds}
    refs={s:groups[f'scale/epochs/600/open/{s}'] for s in seeds}
    y=np.array([[float(refs[s][i]['truth']) for i in ids[s]] for s in seeds])
    cl=np.array([[refs[s][i]['cluster_id'] for i in ids[s]] for s in seeds])
    check(all(len(ids[s])==400 for s in seeds),'Budget each seed has 400 unique permitted evaluation IDs')
    check(len({tuple(sorted(set(c))) for c in cl})==1,'Budget all seeds share the same 46-cluster set, records need not be identical')
    global_identity={}
    for group,d in groups.items():
        seed=int(group.rsplit('/',1)[1]);si=seeds.index(seed)
        check(set(d)==set(ids[seed]), f'Budget exact same record IDs within seed {group}')
        check(all(float(d[i]['truth'])==y[si,j] and d[i]['cluster_id']==cl[si,j] for j,i in enumerate(ids[seed])), f'Budget exact label/cluster pairing within seed {group}')
        check(all(math.isfinite(float(d[i]['prediction'])) for i in ids[seed]), f'Budget finite prediction {group}')
        for rid,r in d.items():
            token=(float(r['truth']),r['cluster_id'])
            check(rid not in global_identity or global_identity[rid]==token,f'Budget exact identity of shared records across seeds {rid}')
            global_identity[rid]=token
    # Authoritative valid v2 only; initial sample_scaling results are not loaded.
    vr=rows(V2/'record_level_predictions.csv.gz')
    n=0;seen=set()
    for r in vr:
        group=f'scale/{r["mode"]}/{r["n"]}/{r["arm"]}/{r["seed"]}'; s=groups[group][r['record_id']]
        check((group,r['record_id']) not in seen,f'Budget valid v2 unique source key {group}/{r["record_id"]}')
        seen.add((group,r['record_id']))
        check(float(r['prediction'])==float(s['prediction']) and float(r['public_V_truth'])==float(s['truth']) and r['cluster_id']==s['cluster_id'], f'Budget v2/public exact values {group}/{r["record_id"]}')
        n+=1
    check(n==len(groups)*400,'Budget valid v2 covers all portable scale rows exactly')
    identity=[]
    for si,s in enumerate(seeds):
        token='\n'.join(f'{rid}\t{y[si,j]:.17g}\t{cl[si,j]}' for j,rid in enumerate(ids[s]))
        identity.append(dict(seed=s,evaluation_records=400,evaluation_clusters=len(set(cl[si])),sorted_record_ids_sha256=hashlib.sha256(('\n'.join(ids[s])+'\n').encode()).hexdigest(),sorted_record_truth_cluster_sha256=hashlib.sha256((token+'\n').encode()).hexdigest(),record_overlap_with_seed32101=len(set(ids[s])&set(ids[32101])),paired_groups=sum(g.endswith('/'+str(s)) for g in groups)))
    table('B_evaluation_identity_by_seed.csv',identity)
    return ids,y,cl,groups

def analyze_budget(new_path=None):
    ids,y,cl,groups=load_budget();seeds=list(range(32101,32106));settings=[('epochs',600,1900),('epochs',1800,5650),('epochs',3000,9400),('steps',3000,1900)]
    clusters,_,weights=cluster_draws(cl[0]);lookup={c:i for i,c in enumerate(clusters)}
    ix=np.array([[lookup[c] for c in row] for row in cl]);errs={};metrics=[]
    def budget_interval(dd,**metadata):
        # Preserve each seed's own 400-record composition and denominator.
        # The same 46-cluster weights are shared across every seed and arm.
        boot=np.array([boot_record_delta(dd[si],np.ones(400,bool),ix[si],weights) for si in range(5)]).T
        valid=np.isfinite(boot).all(axis=1)
        values=np.full(B,np.nan);values[valid]=boot[valid].mean(axis=1)
        return ci(values,dd.mean(),**metadata,evaluation_records_per_seed=400,evaluation_unique_records=len(set(i for ss in ids.values() for i in ss)),evaluation_clusters=len(clusters))
    for mode,n,steps in settings:
        for arm in ('open','periodic'):
            arr=[]
            for si,seed in enumerate(seeds):
                d=groups[f'scale/{mode}/{n}/{arm}/{seed}'];e=np.array([float(d[i]['prediction']) for i in ids[seed]])-y[si];arr.append(e)
                metrics.append(dict(mode=mode,labels=n,updates=steps,seed=seed,arm=arm,n=400,clusters=len(clusters),mae=float(abs(e).mean()),high_n=int((y[si]>=.3).sum()),high_mae=float(abs(e[y[si]>=.3]).mean()),bias=float(e.mean())))
            errs[mode,n,arm]=np.array(arr)
    # New saved predictions may be joined later with --new-budget-predictions.
    if new_path is not None:
        nr=rows(new_path); ng=defaultdict(dict)
        metadata=js(new_path.parent/'identity_metadata.json')
        newlock=js(new_path.parent/'prediction_lock.json');newprotocol=js(new_path.parent/'protocol.json')
        newqa=js(new_path.parent/'FINAL_QA.json')
        check(newlock['all_ten_completed'] and len(newlock['runs'])==10,'New budget all10 predictions locked before scoring')
        check(newlock['protocol_sha256']==sha(new_path.parent/'protocol.json'),'New budget frozen protocol hash')
        check(newqa['status']=='PASS' and len(newqa['checks'])==10 and all(r['steps']==9400 and r['exact_lr_curve_points']==r['finite_curve_rows'] for r in newqa['checks']),'New budget branch QA certifies all10 exact logged update-based LR points')
        for r in nr:
            key=(int(r['seed']),r['arm']);rid=r['record_id']
            check(rid not in ng[key],f'New budget unique {key}/{rid}');ng[key][rid]=r
        check(set(ng)=={(s,a) for s in seeds for a in ('open','periodic')},'New budget exactly 10 paired groups')
        for arm in ('open','periodic'):
            arr=[]
            for si,seed in enumerate(seeds):
                d=ng[seed,arm];check(set(d)==set(ids[seed]),f'New budget exact evaluation identities within seed {seed}/{arm}')
                truthfield='truth' if 'truth' in d[ids[seed][0]] else 'public_V_truth'
                check(all(float(d[i][truthfield])==y[si,j] and d[i]['cluster_id']==cl[si,j] for j,i in enumerate(ids[seed])),f'New budget exact labels/clusters within seed {seed}/{arm}')
                check(all(r.get('n')=='600' and r.get('steps')=='9400' and r.get('mode')=='steps9400' for r in d.values()),f'New budget supplied row metadata is600/9400 {seed}/{arm}')
                check(all(all(r[k]==metadata[rid][k] for k in ('source_uuid','isolation_group','cluster_id')) for rid,r in d.items()),f'New budget exact UUID/isolation identity metadata {seed}/{arm}')
                run=f'steps_n600_{seed}_{arm}';receipt=next(r for r in newlock['runs'] if r['run']==run)
                rawpath=new_path.parent/run/'predictions.csv';raw={r['record_id']:r for r in rows(rawpath)}
                check(sha(rawpath)==receipt['prediction_sha256'],'New budget frozen raw prediction hash '+run)
                check(set(raw)==set(d) and all(float(raw[i]['prediction'])==float(d[i]['prediction']) for i in d),'New budget scored/raw exact prediction values '+run)
                e=np.array([float(d[i]['prediction']) for i in ids[seed]])-y[si];check(np.isfinite(e).all(),f'New budget finite {seed}/{arm}');arr.append(e)
                metrics.append(dict(mode='steps9400',labels=600,updates=9400,seed=seed,arm=arm,n=400,clusters=len(clusters),mae=float(abs(e).mean()),high_n=int((y[si]>=.3).sum()),high_mae=float(abs(e[y[si]>=.3]).mean()),bias=float(e.mean())))
            errs['steps9400',600,arm]=np.array(arr)
        settings.append(('steps9400',600,9400))
    diffs=[];intervals=[];vectors={}
    for mode,n,steps in settings:
        da=abs(errs[mode,n,'periodic'])-abs(errs[mode,n,'open']);delta=da.mean(axis=0);vectors[mode,n]=da
        for i,s in enumerate(seeds):diffs.append(dict(contrast=f'{mode}_{n}_periodic_minus_open',seed=s,mae_difference=float(da[i].mean()),updates=steps,labels=n))
        intervals.append(budget_interval(da,contrast=f'{mode}_{n}_periodic_minus_open',endpoint='mae',updates=steps,labels=n))
    contrasts=[('epochs_3000_minus_epochs_600',vectors['epochs',3000]-vectors['epochs',600],'9400_vs_1900_updates; same_50_epochs'),
               ('epochs_1800_minus_epochs_600',vectors['epochs',1800]-vectors['epochs',600],'5650_vs_1900_updates; same_50_epochs'),
               ('steps1900_3000_minus_600',vectors['steps',3000]-vectors['epochs',600],'same_1900_updates; warmup76'),
               ('3000_steps9400_minus_steps1900',vectors['epochs',3000]-vectors['steps',3000],'same_3000_labels; schedule_and_updates_change')]
    if new_path is not None:
        contrasts.append(('steps9400_3000_minus_600',vectors['epochs',3000]-vectors['steps9400',600],'same_9400_updates; aligned_long_schedule'))
        contrasts.append(('interaction_budget_delta_long_minus_short',vectors['epochs',3000]-vectors['steps9400',600]-vectors['steps',3000]+vectors['epochs',600],'(Delta3000-Delta600)9400 minus same contrast1900'))
    for label,dd,basis in contrasts:
        for i,s in enumerate(seeds):diffs.append(dict(contrast=label,seed=s,mae_difference=float(dd[i].mean()),basis=basis))
        delta=dd.mean(axis=0)
        intervals.append(budget_interval(dd,contrast=label,endpoint='difference_in_differences_mae',basis=basis))
    # Direct label-budget effects within each arm are useful alongside the interaction.
    within=[('1900','steps',3000,'epochs',600)]
    if new_path is not None:within.append(('9400','epochs',3000,'steps9400',600))
    for steps,am,an,bm,bn in within:
        for arm in ('open','periodic'):
            dd=abs(errs[am,an,arm])-abs(errs[bm,bn,arm]);delta=dd.mean(axis=0)
            for i,s in enumerate(seeds):diffs.append(dict(contrast=f'steps{steps}_3000_minus_600_{arm}',seed=s,mae_difference=float(dd[i].mean()),basis=f'same_{steps}_updates'))
            intervals.append(budget_interval(dd,contrast=f'steps{steps}_3000_minus_600_{arm}',endpoint='mae_budget_effect_within_arm',basis=f'same_{steps}_updates'))
    if new_path is not None:
        for arm in ('open','periodic'):
            extra=[(f'n600_steps9400_minus_steps1900_{arm}',abs(errs['steps9400',600,arm])-abs(errs['epochs',600,arm]),'same600_labels; optimization_budget_and_schedule_change'),
                   (f'n3000_steps9400_minus_steps1900_{arm}',abs(errs['epochs',3000,arm])-abs(errs['steps',3000,arm]),'same3000_labels; optimization_budget_and_schedule_change'),
                   (f'labels_by_schedule_interaction_{arm}',abs(errs['epochs',3000,arm])-abs(errs['steps9400',600,arm])-abs(errs['steps',3000,arm])+abs(errs['epochs',600,arm]),'(MAE3000-MAE600)9400 minus same contrast1900')]
            for name,dd,basis in extra:
                for i,s in enumerate(seeds):diffs.append(dict(contrast=name,seed=s,mae_difference=float(dd[i].mean()),basis=basis))
                intervals.append(budget_interval(dd,contrast=name,endpoint='schedule_effect_or_interaction_within_arm',basis=basis))
    table('B_per_seed_metrics.csv',metrics);table('B_per_seed_paired_differences.csv',diffs);table('B_conditional_intervals.csv',intervals)
    summary=[]
    for mode,n,steps in settings:
        for arm in ('open','periodic'):
            rr=[r for r in metrics if r['mode']==mode and r['labels']==n and r['arm']==arm]
            for endpoint in ('mae','bias','high_mae'):
                vv=[r[endpoint] for r in rr]
                summary.append(dict(mode=mode,labels=n,updates=steps,arm=arm,endpoint=endpoint,mean=float(np.mean(vv)),seed_sd=float(np.std(vv,ddof=1)),paired_runs=5,sd_scope='run-to-run sample SD; not population CI'))
    table('B_summary_metrics.csv',summary)
    status=dict(new600_9400_received=new_path is not None,waiting=[] if new_path is not None else ['10 saved predictions: 600 labels, 9400 updates, open/periodic, five paired seeds 32101..32105','Scoring truth and cluster columns must exactly match each seed own frozen original400 evaluation identities','Budget branch must verify aligned update-based LR schedule and fixed endpoint; paired analysis never certifies training history from predictions alone'],identity=dict(evaluation_records_per_seed=400,evaluation_unique_records=len(set(i for ss in ids.values() for i in ss)),evaluation_clusters=len(clusters),seeds=seeds,exact_truth_cluster_pairing_within_seed=True,shared_cluster_draw_across_seeds=True))
    save('B_status.json',status)
    return dict(metrics=metrics,intervals=intervals,status=status)

def run_analysis(input_root, output_root):
    global ROOT,OUT,HK,REPRO,V2,SOURCES,CHECKS
    ROOT=Path(input_root).resolve();OUT=Path(output_root).resolve();HK=ROOT/'hk';REPRO=ROOT/'reproduction';V2=ROOT/'v2'
    SOURCES={};CHECKS=[]
    OUT.mkdir(parents=True,exist_ok=True)
    a=analyze_high();b=analyze_budget(ROOT/'budget/record_level_predictions.csv.gz')
    save('input_hashes.json',SOURCES)
    save('analysis_receipt.json',dict(bootstrap_seed=RNG_SEED,bootstrap_draws=B,fit=0,forward=0,checkpoint_loads=0,exact_checks_completed=len(CHECKS),A_identity=a['identity'],B_status=b['status'],scope='Conditional on fixed fitted models and observed evaluation cohort; retrospective same-source MD; not independent-source validation.'))
    return a,b
