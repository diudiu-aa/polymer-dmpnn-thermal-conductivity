"""Render the three scientific figures using recomputed paired tables.
APFE individual references are downloaded/received transiently, never bundled.
"""
import argparse,json,shutil,subprocess,sys,tempfile
from pathlib import Path
from integrity import BASE,verify_package

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--replay-output',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--figure',choices=['A','B','C','all'],default='all');ap.add_argument('--download-reference',action='store_true');ap.add_argument('--reference-csv',type=Path);a=ap.parse_args();verify_package()
 v=json.loads((a.replay_output/'verification.json').read_text())
 if v['status']!='PASS' or v['new_models']!=25:raise ValueError('A completed25-model replay is required')
 if a.figure in ('A','all') and not (a.download_reference or a.reference_csv):ap.error('Figure A requires --download-reference or --reference-csv for the checksum-locked author CSV')
 output=a.output.resolve();output.mkdir(parents=True,exist_ok=False)
 with tempfile.TemporaryDirectory(prefix='completion-figure-source-') as tmp:
  src=Path(tmp)/'source_data';shutil.copytree(BASE/'figures/source_data',src)
  replaced=[]
  for f in src.iterdir():
   candidate=a.replay_output/f.name
   if candidate.is_file() and f.name.startswith(('A_','B_')):shutil.copyfile(candidate,f);replaced.append(f.name)
  cmd=[sys.executable,str(BASE/'figures/code/make_figures.py'),'--figure',a.figure,'--source-dir',str(src),'--output-dir',str(output)]
  if a.download_reference:cmd.append('--download-reference')
  if a.reference_csv:cmd+=['--reference-csv',str(a.reference_csv.resolve())]
  subprocess.run(cmd,check=True)
 (output/'replot_receipt.json').write_text(json.dumps({'figure':a.figure,'recomputed_paired_tables':replaced,'fit':0,'forward':0,'APFE_individual_reference_redistribution':False},indent=2)+'\n')
if __name__=='__main__':main()
