"""Recompute graph/role counts and structure-equal weighting from saved identities."""
from collections import defaultdict
import csv
from integrity import read_csv,load_json

def write(path,rows):
 with path.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def run(data,out):
 graph={r['record_id']:r for r in read_csv(data/'metadata/graph_identity.csv')};meta={r['record_id']:r for r in read_csv(data/'metadata/scaling_training_identities.csv')};selection=load_json(data/'metadata/scaling_selection.json');counts=[]
 for seed,sp in selection.items():
  for n,ids in sp['train'].items():
   ng=len({graph[i]['graph_id'] for i in ids});counts.append({'seed':seed,'n_locked_records':n,'records':len(ids),'unique_graph_id':ng,'unique_isolation_group':len({graph[i]['isolation_group'] for i in ids}),'unique_cluster_id':len({meta[i]['cluster_id'] for i in ids}),'duplicate_graph_observation_fraction':1-ng/len(ids)})
 write(out/'nested_training_structure_counts.csv',counts)
 groups=defaultdict(list)
 for r in read_csv(data/'v2/record_level_predictions.csv.gz'):groups[r['seed'],r['n'],r['mode'],r['arm']].append(r)
 sensitivity=[]
 for key,rr in sorted(groups.items()):
  for regime,sub in [('overall',rr),('fixed_kappa_ge_0.30',[r for r in rr if float(r['public_V_truth'])>=.30])]:
   if not sub:continue
   graphmeans=defaultdict(list);isomeans=defaultdict(list);errors=[]
   for r in sub:
    e=abs(float(r['prediction'])-float(r['public_V_truth']));identity=graph[r['record_id']];errors.append(e);graphmeans[identity['graph_id']].append(e);isomeans[identity['isolation_group']].append(e)
   sensitivity.append({'seed':key[0],'n':key[1],'mode':key[2],'arm':key[3],'subset':regime,'records':len(sub),'unique_graph_id':len(graphmeans),'unique_isolation_group':len(isomeans),'unique_cluster_id':len({r['cluster_id'] for r in sub}),'mae_record_weighted':sum(errors)/len(errors),'mae_graph_equal':sum(sum(v)/len(v) for v in graphmeans.values())/len(graphmeans),'mae_isolation_group_equal':sum(sum(v)/len(v) for v in isomeans.values())/len(isomeans),'records_missing_pool_identity':0,'records_missing_graph_id':0})
 write(out/'saved_prediction_mae_weighting_sensitivity.csv',sensitivity)
 return len(counts),len(sensitivity)
