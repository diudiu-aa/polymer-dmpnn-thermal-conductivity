"""Integrity and safe local extraction for the completion release."""
import csv,gzip,hashlib,json,math,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load_json(path):return json.loads(Path(path).read_text())
def read_csv(path):
 path=Path(path)
 with (gzip.open(path,'rt',newline='') if path.suffix=='.gz' else path.open(newline='')) as f:return list(csv.DictReader(f))
def verify_package(base=BASE):
 base=Path(base);manifest=load_json(base/'manifest.json')
 expected=(base/'MANIFEST.sha256').read_text().split()[0]
 if sha(base/'manifest.json')!=expected:raise ValueError('MANIFEST_CHECKSUM_MISMATCH')
 for rel,digest in manifest['files'].items():
  p=Path(rel)
  if p.is_absolute() or '..' in p.parts:raise ValueError('UNSAFE_RESOURCE_PATH')
  target=base/p
  if not target.is_file():raise ValueError('MISSING_RESOURCE: '+rel)
  if sha(target)!=digest:raise ValueError('SOURCE_OR_RESOURCE_CHANGED: '+rel)
 for rel,digest in manifest.get('external_files',{}).items():
  p=Path(rel)
  if p.is_absolute() or '..' in p.parts:raise ValueError('UNSAFE_EXTERNAL_RESOURCE_PATH')
  target=base.parents[1]/p
  if not target.is_file() or sha(target)!=digest:raise ValueError('SHARED_SOURCE_OR_INPUT_CHANGED: '+rel)
 registry=load_json(base/'registry.json')['models']
 wanted={f'budget_{s}_{a}' for s in range(32101,32106) for a in ('open','periodic')}|{f'hk01_{s}_{a}' for s in range(43101,43106) for a in ('mse','q90_weight2','multitask')}
 if set(registry)!=wanted:raise ValueError('INCOMPLETE_25_MODEL_REGISTRY')
 for name,spec in registry.items():
  if sha(base/spec['file'])!=spec['sha256']:raise ValueError('CHECKPOINT_MISMATCH: '+name)
 return manifest,registry

def unpack(destination,base=BASE):
 destination=Path(destination);destination.mkdir(parents=True,exist_ok=True)
 with tarfile.open(Path(base)/'data/analysis_inputs.tar.gz','r:gz') as archive:
  total=0
  for member in archive.getmembers():
   p=Path(member.name);total+=member.size
   if p.is_absolute() or '..' in p.parts or not member.isfile() or member.size>30_000_000 or total>80_000_000:raise ValueError('UNSAFE_ARCHIVE_MEMBER')
   target=destination/p;target.parent.mkdir(parents=True,exist_ok=True)
   with archive.extractfile(member) as source,target.open('wb') as f:f.write(source.read())
 return destination

def validate_pairing(groups,required_groups=None):
 """Check numerical values and row identities before any metric calculation.

 groups is a mapping of group keys to records with record_id/truth/cluster_id/
 prediction. Keys should prefix a cohort identifier and training seed.
 """
 if required_groups is not None and set(groups)!=set(required_groups):raise ValueError('MISSING_OR_UNEXPECTED_MODEL_GROUP')
 truth_by_id={}
 cohorts={}
 for name,rows in groups.items():
  ids=[r['record_id'] for r in rows]
  if len(ids)!=len(set(ids)):raise ValueError('DUPLICATE_RECORD_ID')
  cohort={}
  for r in rows:
   y=float(r['truth']);p=float(r['prediction'])
   if not math.isfinite(y) or not math.isfinite(p):raise ValueError('NONFINITE_REFERENCE_OR_PREDICTION')
   token=(y,str(r['cluster_id']))
   if r['record_id'] in truth_by_id and truth_by_id[r['record_id']]!=token:raise ValueError('PAIRED_TRUTH_OR_CLUSTER_MISMATCH')
   truth_by_id[r['record_id']]=token;cohort[r['record_id']]=token
  # The caller supplies (cohort, seed, arm) so arms share exact IDs/truth.
  key=name[:2]
  if key in cohorts and cohorts[key]!=cohort:raise ValueError('PAIRED_COHORT_MISMATCH')
  cohorts[key]=cohort
 return True
