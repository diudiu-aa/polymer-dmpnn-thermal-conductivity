"""Recompute completion metrics and paired analyses from released record values.
No checkpoint imports, fitting, model inference, network, or parent data access.
"""
import argparse,csv,json,math,platform,tempfile
from pathlib import Path
import numpy as np
from integrity import BASE,load_json,read_csv,unpack,validate_pairing,verify_package

def table(path,rows):
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with Path(path).open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def save(path,obj):Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def metrics(y,p,q,logit=None):
 ae=abs(y-p);err=p-y;high=y>=.30;tail=y>=q
 r={'n':len(y),'evaluation_n':len(y),'mae':float(ae.mean()),'rmse':float(np.sqrt((err**2).mean())),'r2':float(1-(err**2).sum()/((y-y.mean())**2).sum()),'bias':float(err.mean()),'train_q95':q,'q95_n':int(tail.sum()),'q95_mae':float(ae[tail].mean()),'q95_bias':float(err[tail].mean()),'fixed030_n':int(high.sum()),'fixed030_mae':float(ae[high].mean()),'fixed030_bias':float(err[high].mean()),'high_n':int(high.sum()),'high_mae':float(ae[high].mean()),'high_bias':float(err[high].mean()),'train_q95_tail_n':int(tail.sum()),'train_q95_tail_mae':float(ae[tail].mean())}
 for k in (10,20,50,100):
  hits=len(set(np.argsort(-y,kind='stable')[:k])&set(np.argsort(-p,kind='stable')[:k]));r[f'hits_at_{k}']=hits;r[f'precision_at_{k}']=hits/k;r[f'top{k}_overlap']=hits/k
  if logit is not None:r[f'class_top{k}_overlap']=len(set(np.argsort(-y,kind='stable')[:k])&set(np.argsort(-logit,kind='stable')[:k]))/k
 return r

def recompute_metrics(data,registry,out):
 groups={};rawhk={}
 hk=read_csv(data/'hk/scored_predictions.csv')
 for row in hk:groups.setdefault(('hk01',int(row['seed']),row['arm']),[]).append(row)
 for row in read_csv(data/'budget/record_level_predictions.csv.gz'):
  groups.setdefault(('budget',int(row['seed']),row['arm']),[]).append({**row,'truth':row['public_V_truth']})
 required={(spec['family'],spec['seed'],spec['arm']) for spec in registry.values()};validate_pairing(groups,required)
 results=[];reference=[]
 for row in read_csv(data/'expected_metrics/hk_per_seed_metrics.csv'):reference.append(('hk01',row))
 for row in load_json(data/'expected_metrics/budget_metrics.json'):reference.append(('budget',row))
 count=0
 for model_id,spec in registry.items():
  family=spec['family'];seed=spec['seed'];arm=spec['arm'];rr=groups[family,seed,arm]
  if family=='hk01':rr=sorted(rr,key=lambda r:r['record_id'])
  y=np.array([float(r['truth']) for r in rr]);p=np.array([float(r['prediction']) for r in rr]);logit=None
  if family=='hk01' and arm=='multitask':
   raw={r['record_id']:r for r in read_csv(data/f'hk/{seed}_{arm}/predictions.csv')};logit=np.array([float(raw[r['record_id']]['classifier_score']) for r in rr])
   if not np.isfinite(logit).all():raise ValueError('NONFINITE_CLASSIFIER_LOGIT')
  r={'model_id':model_id,'family':family,'seed':seed,'arm':arm,**metrics(y,p,spec['train_q95'],logit)}
  r['training_records']=spec['training_records']
  if family=='budget':r['n']=spec['training_records']
  original=next(row for kind,row in reference if kind==family and int(row['seed'])==seed and row['arm']==arm)
  for key,value in original.items():
   if key in r and key not in ('model_id','family','seed','arm') and value not in ('',None):
    if abs(float(r[key])-float(value))>1e-11:raise ValueError('METRIC_REFERENCE_MISMATCH '+model_id+' '+key)
    count+=1
  results.append(r)
 table(out/'new25_per_seed_metrics.csv',results);save(out/'new25_per_seed_metrics.json',results)
 summary=[]
 for family,arm in sorted({(r['family'],r['arm']) for r in results}):
  rr=[r for r in results if (r['family'],r['arm'])==(family,arm)]
  for endpoint in ('mae','r2','bias','high_mae','high_bias','top10_overlap','top20_overlap','top50_overlap','top100_overlap'):
   z=[r[endpoint] for r in rr];summary.append({'family':family,'arm':arm,'endpoint':endpoint,'mean':float(np.mean(z)),'seed_sd':float(np.std(z,ddof=1)),'runs':len(z)})
 table(out/'new25_summary_metrics.csv',summary)
 return count

def verify_analysis(data,out):
 files=0;values=0
 for expected in sorted(list((data/'expected_analysis').glob('*.csv'))+list((data/'expected_structure').glob('*.csv'))):
  actual=out/expected.name
  if not actual.is_file():raise ValueError('MISSING_RECOMPUTED_ANALYSIS '+expected.name)
  er=read_csv(expected);ar=read_csv(actual)
  if len(er)!=len(ar):raise ValueError('ANALYSIS_ROW_COUNT '+expected.name)
  for a,b in zip(er,ar):
   if set(a)!=set(b):raise ValueError('ANALYSIS_COLUMN_MISMATCH '+expected.name)
   for key in a:
    try:x=float(a[key]);y=float(b[key])
    except (ValueError,TypeError):
     if a[key]!=b[key]:raise ValueError('ANALYSIS_TEXT_MISMATCH '+expected.name+' '+key)
    else:
     if not math.isfinite(x) or not math.isfinite(y) or abs(x-y)>1e-10:raise ValueError('ANALYSIS_NUMERIC_MISMATCH '+expected.name+' '+key)
     values+=1
  files+=1
 return files,values

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 manifest,registry=verify_package()
 import paired_math,inventory
 out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 with tempfile.TemporaryDirectory(prefix='completion-replay-') as tmp:
  data=unpack(Path(tmp)/'inputs');metric_checks=recompute_metrics(data,registry,out)
  paired_math.run_analysis(data,out);inventory.run(data,out);files,values=verify_analysis(data,out)
 save(out/'verification.json',{'status':'PASS','new_models':25,'new_metric_checks':metric_checks,'paired_analysis_files_recomputed':files,'paired_analysis_numeric_checks':values,'reference_copies_used_as_computation':False,'bootstrap_draws':5000,'bootstrap_seed':2026102907,'fit':0,'forward':0,'checkpoint_loads':0,'python':platform.python_version(),'numpy':np.__version__,'scope':'Saved-prediction replay; conditional fixed-fit cohort intervals. Not training, inference, independent-source or blind validation.'})
 print(json.dumps({'status':'PASS','new_models':25,'metric_checks':metric_checks,'analysis_files':files,'analysis_numeric_checks':values,'output':str(args.output)}))
if __name__=='__main__':main()
